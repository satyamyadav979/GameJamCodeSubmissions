using System;
using BitGrid.Core;
using BitGrid.Generation;
using NUnit.Framework;

namespace BitGrid.Tests.EditMode
{
    /// <summary>
    /// Integration tests for <see cref="PuzzleGenerator"/>: end-to-end correctness,
    /// determinism by seed, and difficulty-window enforcement.
    /// </summary>
    [TestFixture]
    public class PuzzleGeneratorTests
    {
        [TestCase(3, PuzzleDifficulty.Easy)]
        [TestCase(3, PuzzleDifficulty.Medium)]
        [TestCase(3, PuzzleDifficulty.Hard)]
        [TestCase(4, PuzzleDifficulty.Easy)]
        [TestCase(4, PuzzleDifficulty.Medium)]
        [TestCase(4, PuzzleDifficulty.Hard)]
        [TestCase(5, PuzzleDifficulty.Easy)]
        [TestCase(5, PuzzleDifficulty.Medium)]
        [TestCase(5, PuzzleDifficulty.Hard)]
        public void Generate_AllSizeDifficulty_YieldsUniqueNonTrivialPuzzle(
            int size, PuzzleDifficulty difficulty)
        {
            // Try several seeds so we don't wedge the test on a single pathological RNG state.
            Puzzle puzzle = null;
            Exception last = null;
            for (int seed = 1; seed <= 10 && puzzle == null; seed++)
            {
                try
                {
                    puzzle = PuzzleGenerator.Generate(
                        size, difficulty, WeightingMode.UnitCount, seed: seed);
                }
                catch (Exception ex)
                {
                    last = ex;
                }
            }

            Assert.NotNull(puzzle, $"Generator failed across 10 seeds: {last}");
            Assert.AreEqual(size, puzzle.Size);
            Assert.IsFalse(puzzle.IsSolved(), "Puzzle must not be solved at construction.");
            Assert.IsTrue(Solver.HasUniqueSolution(puzzle),
                "Generated puzzle must be uniquely solvable.");

            bool hasOneNonLockedCell = false;
            for (int i = 0; i < puzzle.Size && !hasOneNonLockedCell; i++)
            {
                for (int j = 0; j < puzzle.Size; j++)
                {
                    if (!puzzle.Locked[i, j] && puzzle.Solution[i, j] == CellState.One)
                    {
                        hasOneNonLockedCell = true;
                        break;
                    }
                }
            }
            Assert.IsTrue(hasOneNonLockedCell,
                "Player must have at least one non-locked cell to flip to reach the solution.");
        }

        [Test]
        public void Generate_SameSeedTwice_YieldsIdenticalSolutionAndLockMask()
        {
            var a = PuzzleGenerator.Generate(
                4, PuzzleDifficulty.Medium, WeightingMode.UnitCount, seed: 7);
            var b = PuzzleGenerator.Generate(
                4, PuzzleDifficulty.Medium, WeightingMode.UnitCount, seed: 7);

            Assert.AreEqual(a.Size, b.Size);
            for (int i = 0; i < a.Size; i++)
            {
                for (int j = 0; j < a.Size; j++)
                {
                    Assert.AreEqual(a.Solution[i, j], b.Solution[i, j],
                        $"Solution differs at ({i},{j}) for same seed.");
                    Assert.AreEqual(a.Locked[i, j], b.Locked[i, j],
                        $"Lock mask differs at ({i},{j}) for same seed.");
                }
            }
        }

        [TestCase(5, PuzzleDifficulty.Easy, 0.55, 0.85)]
        [TestCase(5, PuzzleDifficulty.Medium, 0.30, 0.60)]
        [TestCase(5, PuzzleDifficulty.Hard, 0.00, 0.20)]
        public void Generate_LockDensity_IsWithinDifficultyWindow(
            int size, PuzzleDifficulty difficulty, double loRatio, double hiRatio)
        {
            var puzzle = PuzzleGenerator.Generate(
                size, difficulty, WeightingMode.UnitCount, seed: 123);

            int lockCount = 0;
            for (int i = 0; i < size; i++)
                for (int j = 0; j < size; j++)
                    if (puzzle.Locked[i, j]) lockCount++;

            double ratio = (double)lockCount / (size * size);
            Assert.GreaterOrEqual(ratio, loRatio,
                $"Lock ratio {ratio:F2} below {difficulty} window [{loRatio}, {hiRatio}].");
            Assert.LessOrEqual(ratio, hiRatio,
                $"Lock ratio {ratio:F2} above {difficulty} window [{loRatio}, {hiRatio}].");
        }

        [Test]
        public void Generate_InvalidSize_ThrowsArgumentOutOfRangeException()
        {
            Assert.Throws<ArgumentOutOfRangeException>(
                () => PuzzleGenerator.Generate(1, PuzzleDifficulty.Easy));
            Assert.Throws<ArgumentOutOfRangeException>(
                () => PuzzleGenerator.Generate(0, PuzzleDifficulty.Easy));
            Assert.Throws<ArgumentOutOfRangeException>(
                () => PuzzleGenerator.Generate(-3, PuzzleDifficulty.Easy));
        }

        [TestCase(PuzzleDifficulty.Easy,   4, 0, 0)]
        [TestCase(PuzzleDifficulty.Medium, 5, 0, 0)]
        [TestCase(PuzzleDifficulty.Hard,   6, 2, 2)]
        public void Generate_PositionalBinary_MatchesDifficultyConfig(
            PuzzleDifficulty difficulty, int expectedSize, int expectedHiddenRows, int expectedHiddenCols)
        {
            Puzzle puzzle = null;
            Exception last = null;
            for (int seed = 1; seed <= 10 && puzzle == null; seed++)
            {
                try
                {
                    puzzle = PuzzleGenerator.Generate(
                        size: 2, // will be overridden up to the config size
                        difficulty: difficulty,
                        mode: WeightingMode.PositionalBinary,
                        seed: seed);
                }
                catch (Exception ex) { last = ex; }
            }

            Assert.NotNull(puzzle, $"PositionalBinary generation failed across seeds: {last}");
            Assert.AreEqual(WeightingMode.PositionalBinary, puzzle.Mode);
            Assert.AreEqual(expectedSize, puzzle.Size);
            Assert.IsTrue(Solver.HasUniqueSolution(puzzle));

            int hiddenRows = 0, hiddenCols = 0;
            for (int i = 0; i < puzzle.Size; i++)
            {
                if (!puzzle.RowTargetVisible[i]) hiddenRows++;
                if (!puzzle.ColTargetVisible[i]) hiddenCols++;
            }
            Assert.AreEqual(expectedHiddenRows, hiddenRows, "Hidden row count mismatch.");
            Assert.AreEqual(expectedHiddenCols, hiddenCols, "Hidden column count mismatch.");

            // Exactly hiddenRows * hiddenCols locked cells at the hidden intersections,
            // zero elsewhere.
            int lockCount = 0;
            for (int i = 0; i < puzzle.Size; i++)
            {
                for (int j = 0; j < puzzle.Size; j++)
                {
                    if (!puzzle.Locked[i, j]) continue;
                    lockCount++;
                    Assert.IsFalse(puzzle.RowTargetVisible[i],
                        $"Locked cell ({i},{j}) is not on a hidden row.");
                    Assert.IsFalse(puzzle.ColTargetVisible[j],
                        $"Locked cell ({i},{j}) is not on a hidden column.");
                }
            }
            Assert.AreEqual(expectedHiddenRows * expectedHiddenCols, lockCount,
                "Lock count should equal hiddenRows * hiddenCols.");
        }
    }
}
