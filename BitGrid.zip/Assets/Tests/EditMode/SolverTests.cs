using BitGrid.Core;
using BitGrid.Generation;
using NUnit.Framework;

namespace BitGrid.Tests.EditMode
{
    /// <summary>
    /// Unit tests for <see cref="Solver"/>: uniqueness detection, cap behavior,
    /// locked-cell honoring, and mode-specific correctness.
    /// </summary>
    [TestFixture]
    public class SolverTests
    {
        private static CellState[,] Xor2x2() => new CellState[2, 2]
        {
            { CellState.One, CellState.Zero },
            { CellState.Zero, CellState.One },
        };

        [Test]
        public void Xor2x2_WithoutLocks_HasExactlyTwoSolutions()
        {
            var p = new Puzzle(2, WeightingMode.UnitCount, Xor2x2(), new bool[2, 2]);
            Assert.AreEqual(2, Solver.CountSolutionsUpTo(p, 5));
            Assert.IsFalse(Solver.HasUniqueSolution(p));
        }

        [Test]
        public void Xor2x2_OneLock_BecomesUniqueSolution()
        {
            var locked = new bool[2, 2];
            locked[0, 0] = true;
            var p = new Puzzle(2, WeightingMode.UnitCount, Xor2x2(), locked);

            Assert.AreEqual(1, Solver.CountSolutionsUpTo(p, 5));
            Assert.IsTrue(Solver.HasUniqueSolution(p));
        }

        [Test]
        public void Cap_StopsAtProvidedUpperBound()
        {
            var p = new Puzzle(2, WeightingMode.UnitCount, Xor2x2(), new bool[2, 2]);
            Assert.AreEqual(1, Solver.CountSolutionsUpTo(p, 1));
            Assert.AreEqual(2, Solver.CountSolutionsUpTo(p, 2));
            Assert.AreEqual(2, Solver.CountSolutionsUpTo(p, 99));
        }

        [Test]
        public void Cap_ZeroOrNegative_ReturnsZero()
        {
            var p = new Puzzle(2, WeightingMode.UnitCount, Xor2x2(), new bool[2, 2]);
            Assert.AreEqual(0, Solver.CountSolutionsUpTo(p, 0));
            Assert.AreEqual(0, Solver.CountSolutionsUpTo(p, -10));
        }

        [Test]
        public void HandAuthored3x3_UnitCount_IsUnique()
        {
            // Row 0 target = 3 forces [1,1,1]; Col 0 target = 3 forces [1,1,1] in col 0.
            // Row 1 target 2 with col 0 already filled means exactly one of (1,1)/(1,2) is 1.
            // Col 1 target 2 forces (1,1) = 1, which then uniquely determines the rest.
            var sol = new CellState[3, 3]
            {
                { CellState.One, CellState.One, CellState.One },
                { CellState.One, CellState.One, CellState.Zero },
                { CellState.One, CellState.Zero, CellState.Zero },
            };
            var p = new Puzzle(3, WeightingMode.UnitCount, sol, new bool[3, 3]);
            Assert.AreEqual(1, Solver.CountSolutionsUpTo(p, 5));
        }

        [Test]
        public void PositionalBinary_AlwaysUnique_BecauseRowDecodesDirectlyToBits()
        {
            // Under PositionalBinary, within any row the column weights are distinct
            // powers of two (1, 2, 4, ...), so the row target uniquely decodes the
            // row's bit pattern. Any valid puzzle in this mode therefore has exactly
            // one solution - a good sanity check on the solver's per-axis weights.
            var sol = new CellState[3, 3]
            {
                { CellState.One, CellState.Zero, CellState.One },
                { CellState.Zero, CellState.One, CellState.Zero },
                { CellState.One, CellState.One, CellState.Zero },
            };
            var p = new Puzzle(3, WeightingMode.PositionalBinary, sol, new bool[3, 3]);
            Assert.AreEqual(1, Solver.CountSolutionsUpTo(p, 5));
        }

        [Test]
        public void AllCellsLocked_SolverFindsExactlyTheLockedSolution()
        {
            var sol = new CellState[3, 3]
            {
                { CellState.One, CellState.Zero, CellState.One },
                { CellState.Zero, CellState.One, CellState.One },
                { CellState.One, CellState.One, CellState.Zero },
            };
            var locked = new bool[3, 3];
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    locked[i, j] = true;

            var p = new Puzzle(3, WeightingMode.UnitCount, sol, locked);
            Assert.AreEqual(1, Solver.CountSolutionsUpTo(p, 5),
                "Fully-locked puzzle trivially has exactly one solution.");
        }
    }
}
