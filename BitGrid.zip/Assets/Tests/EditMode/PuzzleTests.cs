using BitGrid.Core;
using NUnit.Framework;

namespace BitGrid.Tests.EditMode
{
    /// <summary>
    /// Unit tests for the <see cref="Puzzle"/> runtime model: constructor invariants,
    /// cached sum maintenance across toggles, lock semantics, and mode-specific weights.
    /// </summary>
    [TestFixture]
    public class PuzzleTests
    {
        private static CellState[,] XorSolution() => new CellState[2, 2]
        {
            { CellState.One, CellState.Zero },
            { CellState.Zero, CellState.One },
        };

        [Test]
        public void Constructor_ComputesRowAndColumnTargetsFromSolution()
        {
            var p = new Puzzle(2, WeightingMode.UnitCount, XorSolution(), new bool[2, 2]);
            Assert.AreEqual(1, p.RowTargets[0]);
            Assert.AreEqual(1, p.RowTargets[1]);
            Assert.AreEqual(1, p.ColTargets[0]);
            Assert.AreEqual(1, p.ColTargets[1]);
        }

        [Test]
        public void Constructor_WithoutLocks_StartsWithZeroSumsAndUnsolved()
        {
            var p = new Puzzle(2, WeightingMode.UnitCount, XorSolution(), new bool[2, 2]);
            Assert.AreEqual(0, p.RowSums[0]);
            Assert.AreEqual(0, p.RowSums[1]);
            Assert.AreEqual(0, p.ColSums[0]);
            Assert.AreEqual(0, p.ColSums[1]);
            Assert.IsFalse(p.IsSolved());
        }

        [Test]
        public void Constructor_WithLocks_InitializesCurrentAndSumsFromLocked()
        {
            var locked = new bool[2, 2];
            locked[0, 0] = true;
            var p = new Puzzle(2, WeightingMode.UnitCount, XorSolution(), locked);

            Assert.AreEqual(CellState.One, p.Current[0, 0]);
            Assert.AreEqual(CellState.Zero, p.Current[1, 1]);
            Assert.AreEqual(1, p.RowSums[0]);
            Assert.AreEqual(1, p.ColSums[0]);
            Assert.AreEqual(0, p.RowSums[1]);
            Assert.AreEqual(0, p.ColSums[1]);
        }

        [Test]
        public void Toggle_FlipsStateAndUpdatesCachedSums()
        {
            var p = new Puzzle(2, WeightingMode.UnitCount, XorSolution(), new bool[2, 2]);

            Assert.AreEqual(CellState.One, p.Toggle(0, 0));
            Assert.AreEqual(1, p.RowSums[0]);
            Assert.AreEqual(1, p.ColSums[0]);

            Assert.AreEqual(CellState.Zero, p.Toggle(0, 0));
            Assert.AreEqual(0, p.RowSums[0]);
            Assert.AreEqual(0, p.ColSums[0]);
        }

        [Test]
        public void Toggle_OnLockedCell_DoesNothing()
        {
            var locked = new bool[2, 2];
            locked[0, 0] = true;
            var p = new Puzzle(2, WeightingMode.UnitCount, XorSolution(), locked);

            var before = p.Current[0, 0];
            var result = p.Toggle(0, 0);

            Assert.AreEqual(before, p.Current[0, 0]);
            Assert.AreEqual(before, result);
            Assert.AreEqual(1, p.RowSums[0], "RowSum must not change for locked cell toggle.");
        }

        [Test]
        public void Toggle_OutOfRangeIndices_AreNoOps()
        {
            var p = new Puzzle(2, WeightingMode.UnitCount, XorSolution(), new bool[2, 2]);
            Assert.DoesNotThrow(() => p.Toggle(-1, 0));
            Assert.DoesNotThrow(() => p.Toggle(5, 0));
            Assert.DoesNotThrow(() => p.Toggle(0, -1));
            Assert.DoesNotThrow(() => p.Toggle(0, 5));
            Assert.AreEqual(0, p.RowSums[0]);
        }

        [Test]
        public void IsSolved_TrueWhenCurrentMatchesSolution()
        {
            var p = new Puzzle(2, WeightingMode.UnitCount, XorSolution(), new bool[2, 2]);
            p.Toggle(0, 0);
            p.Toggle(1, 1);
            Assert.IsTrue(p.IsSolved());
        }

        [Test]
        public void ResetToLocked_RestoresLockedAndZerosEverythingElse()
        {
            var locked = new bool[2, 2];
            locked[0, 0] = true;
            var p = new Puzzle(2, WeightingMode.UnitCount, XorSolution(), locked);

            p.Toggle(1, 0);
            p.Toggle(1, 1);
            Assert.AreEqual(CellState.One, p.Current[1, 0]);

            p.ResetToLocked();

            Assert.AreEqual(CellState.One, p.Current[0, 0]);
            Assert.AreEqual(CellState.Zero, p.Current[0, 1]);
            Assert.AreEqual(CellState.Zero, p.Current[1, 0]);
            Assert.AreEqual(CellState.Zero, p.Current[1, 1]);
            Assert.AreEqual(1, p.RowSums[0]);
            Assert.AreEqual(0, p.RowSums[1]);
        }

        [Test]
        public void RecalculateSums_MatchesToggleDrivenSums()
        {
            var p = new Puzzle(2, WeightingMode.UnitCount, XorSolution(), new bool[2, 2]);
            p.Toggle(0, 0);
            p.Toggle(1, 1);

            int r0 = p.RowSums[0], r1 = p.RowSums[1];
            int c0 = p.ColSums[0], c1 = p.ColSums[1];

            p.RecalculateSums();

            Assert.AreEqual(r0, p.RowSums[0]);
            Assert.AreEqual(r1, p.RowSums[1]);
            Assert.AreEqual(c0, p.ColSums[0]);
            Assert.AreEqual(c1, p.ColSums[1]);
        }

        [Test]
        public void Weight_UnitCount_IsAlwaysOneOnBothAxes()
        {
            var p = new Puzzle(2, WeightingMode.UnitCount, XorSolution(), new bool[2, 2]);
            Assert.AreEqual(1, p.RowWeight(0, 0));
            Assert.AreEqual(1, p.RowWeight(1, 1));
            Assert.AreEqual(1, p.ColWeight(0, 1));
            Assert.AreEqual(1, p.ColWeight(1, 0));
        }

        [Test]
        public void Weight_PositionalBinary_RowUses2ToJ_ColumnUses2ToI()
        {
            var p = new Puzzle(3, WeightingMode.PositionalBinary,
                new CellState[3, 3]
                {
                    { CellState.Zero, CellState.Zero, CellState.Zero },
                    { CellState.Zero, CellState.Zero, CellState.Zero },
                    { CellState.Zero, CellState.Zero, CellState.Zero },
                },
                new bool[3, 3]);

            // Row weight is 2^j (column index is the bit position within the row).
            Assert.AreEqual(1, p.RowWeight(0, 0));
            Assert.AreEqual(2, p.RowWeight(0, 1));
            Assert.AreEqual(4, p.RowWeight(2, 2));
            Assert.AreEqual(1, p.RowWeight(2, 0));

            // Column weight is 2^i (row index is the bit position within the column).
            Assert.AreEqual(1, p.ColWeight(0, 0));
            Assert.AreEqual(2, p.ColWeight(1, 0));
            Assert.AreEqual(4, p.ColWeight(2, 2));
            Assert.AreEqual(1, p.ColWeight(0, 2));
        }

        [Test]
        public void PositionalBinary_RowTargetIsBinaryDecodeOfRow()
        {
            // Row 0 = [1, 1, 0, 0]  -> binary 0011 reading LSB-first = 1 + 2 = 3
            // Row 1 = [0, 0, 1, 0]  -> binary 0100 reading LSB-first = 4
            var solution = new CellState[4, 4];
            solution[0, 0] = CellState.One;
            solution[0, 1] = CellState.One;
            solution[1, 2] = CellState.One;

            var p = new Puzzle(4, WeightingMode.PositionalBinary, solution, new bool[4, 4]);

            Assert.AreEqual(3, p.RowTargets[0]);
            Assert.AreEqual(4, p.RowTargets[1]);
            Assert.AreEqual(0, p.RowTargets[2]);
            Assert.AreEqual(0, p.RowTargets[3]);

            // Columns: col 0 has only (0,0); col 1 has only (0,1); col 2 has only (1,2).
            Assert.AreEqual(1, p.ColTargets[0]); // bit 0 of col 0 only
            Assert.AreEqual(1, p.ColTargets[1]);
            Assert.AreEqual(2, p.ColTargets[2]); // bit 1 of col 2
            Assert.AreEqual(0, p.ColTargets[3]);
        }
    }
}
