using System.Collections;
using UnityEngine;

namespace BitGrid.Utils
{
    /// <summary>
    /// Tiny coroutine-based tween helpers. Kept intentionally minimal so we don't
    /// introduce a third-party tween dependency. All tweens respect scaled time and
    /// cancel cleanly if the target is destroyed mid-animation.
    /// </summary>
    public static class UITween
    {
        /// <summary>
        /// Punchy scale pop: from->peak->back-to-1 in <paramref name="durationSeconds"/>.
        /// Ideal for cell-tap feedback. Safe to chain-call while an earlier pop is running;
        /// the component's transform simply re-targets smoothly.
        /// </summary>
        public static IEnumerator Pop(Transform target, float peakScale = 1.12f, float durationSeconds = 0.16f)
        {
            if (target == null) yield break;
            float half = durationSeconds * 0.5f;

            float t = 0f;
            while (t < half)
            {
                if (target == null) yield break;
                t += Time.unscaledDeltaTime;
                float k = Mathf.Clamp01(t / half);
                float s = Mathf.Lerp(1f, peakScale, EaseOutCubic(k));
                target.localScale = new Vector3(s, s, 1f);
                yield return null;
            }

            t = 0f;
            while (t < half)
            {
                if (target == null) yield break;
                t += Time.unscaledDeltaTime;
                float k = Mathf.Clamp01(t / half);
                float s = Mathf.Lerp(peakScale, 1f, EaseOutCubic(k));
                target.localScale = new Vector3(s, s, 1f);
                yield return null;
            }

            if (target != null) target.localScale = Vector3.one;
        }

        /// <summary>
        /// Horizontal shake in unscaled time. Used on incorrect row/column target labels.
        /// </summary>
        public static IEnumerator Shake(RectTransform target, float amplitudePx = 10f, float durationSeconds = 0.35f)
        {
            if (target == null) yield break;
            Vector2 start = target.anchoredPosition;

            float t = 0f;
            while (t < durationSeconds)
            {
                if (target == null) yield break;
                t += Time.unscaledDeltaTime;
                float k = t / durationSeconds;
                float decay = 1f - k;
                float offset = Mathf.Sin(k * Mathf.PI * 12f) * amplitudePx * decay;
                target.anchoredPosition = new Vector2(start.x + offset, start.y);
                yield return null;
            }

            if (target != null) target.anchoredPosition = start;
        }

        /// <summary>
        /// Scale-in entrance: start at <paramref name="startScale"/>, overshoot to
        /// <paramref name="overshootScale"/>, settle at 1. Great for overlay cards
        /// and celebratory elements.
        /// </summary>
        public static IEnumerator ScaleIn(
            Transform target,
            float startScale = 0.6f,
            float overshootScale = 1.08f,
            float durationSeconds = 0.42f)
        {
            if (target == null) yield break;
            target.localScale = new Vector3(startScale, startScale, 1f);

            float rise = durationSeconds * 0.7f;
            float t = 0f;
            while (t < rise)
            {
                if (target == null) yield break;
                t += Time.unscaledDeltaTime;
                float k = Mathf.Clamp01(t / rise);
                float s = Mathf.Lerp(startScale, overshootScale, EaseOutCubic(k));
                target.localScale = new Vector3(s, s, 1f);
                yield return null;
            }

            float settle = durationSeconds * 0.3f;
            t = 0f;
            while (t < settle)
            {
                if (target == null) yield break;
                t += Time.unscaledDeltaTime;
                float k = Mathf.Clamp01(t / settle);
                float s = Mathf.Lerp(overshootScale, 1f, EaseOutCubic(k));
                target.localScale = new Vector3(s, s, 1f);
                yield return null;
            }

            if (target != null) target.localScale = Vector3.one;
        }

        /// <summary>
        /// Smoothly transition an Image's color over a duration.
        /// Caller is responsible for starting the coroutine on a MonoBehaviour.
        /// </summary>
        public static IEnumerator ColorTo(UnityEngine.UI.Graphic target, Color to, float durationSeconds = 0.15f)
        {
            if (target == null) yield break;
            Color from = target.color;

            float t = 0f;
            while (t < durationSeconds)
            {
                if (target == null) yield break;
                t += Time.unscaledDeltaTime;
                target.color = Color.Lerp(from, to, t / durationSeconds);
                yield return null;
            }
            if (target != null) target.color = to;
        }

        private static float EaseOutCubic(float k) => 1f - Mathf.Pow(1f - k, 3f);
    }
}
