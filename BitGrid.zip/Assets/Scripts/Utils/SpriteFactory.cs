using UnityEngine;

namespace BitGrid.Utils
{
    /// <summary>
    /// Procedurally generates the handful of UI sprites BitGrid needs, so the project
    /// ships without any committed art assets. A single white rounded-rect sprite is
    /// generated and reused everywhere (via Image.Type.Sliced + Image.color tinting).
    /// </summary>
    public static class SpriteFactory
    {
        private static Sprite s_rounded;
        private static Sprite s_circle;

        /// <summary>
        /// White sprite with a rounded-rectangle alpha mask, 9-sliced so any Image
        /// size stays rounded without stretching the corner radius.
        /// </summary>
        public static Sprite RoundedRect()
        {
            if (s_rounded != null) return s_rounded;

            const int size = 256;
            const int radius = 32;

            var tex = new Texture2D(size, size, TextureFormat.RGBA32, mipChain: false)
            {
                name = "BitGrid_RoundedRect_Tex",
                wrapMode = TextureWrapMode.Clamp,
                filterMode = FilterMode.Bilinear,
                hideFlags = HideFlags.HideAndDontSave,
            };

            var pixels = new Color32[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float a = RoundedAlpha(x, y, size, radius);
                    byte aByte = (byte)Mathf.Clamp(Mathf.RoundToInt(a * 255f), 0, 255);
                    pixels[y * size + x] = new Color32(255, 255, 255, aByte);
                }
            }
            tex.SetPixels32(pixels);
            tex.Apply(updateMipmaps: false, makeNoLongerReadable: true);

            s_rounded = Sprite.Create(
                tex,
                new Rect(0, 0, size, size),
                new Vector2(0.5f, 0.5f),
                pixelsPerUnit: 100f,
                extrude: 0,
                meshType: SpriteMeshType.FullRect,
                border: new Vector4(radius, radius, radius, radius));
            s_rounded.name = "BitGrid_RoundedRect";
            s_rounded.hideFlags = HideFlags.HideAndDontSave;

            return s_rounded;
        }

        /// <summary>White circular sprite (used for small indicators / badges).</summary>
        public static Sprite Circle()
        {
            if (s_circle != null) return s_circle;

            const int size = 128;
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, mipChain: false)
            {
                name = "BitGrid_Circle_Tex",
                wrapMode = TextureWrapMode.Clamp,
                filterMode = FilterMode.Bilinear,
                hideFlags = HideFlags.HideAndDontSave,
            };

            var pixels = new Color32[size * size];
            float cx = (size - 1) * 0.5f;
            float cy = (size - 1) * 0.5f;
            float r = size * 0.5f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = x - cx;
                    float dy = y - cy;
                    float dist = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.Clamp01(r - dist);
                    byte aByte = (byte)Mathf.Clamp(Mathf.RoundToInt(a * 255f), 0, 255);
                    pixels[y * size + x] = new Color32(255, 255, 255, aByte);
                }
            }
            tex.SetPixels32(pixels);
            tex.Apply(updateMipmaps: false, makeNoLongerReadable: true);

            s_circle = Sprite.Create(
                tex,
                new Rect(0, 0, size, size),
                new Vector2(0.5f, 0.5f),
                pixelsPerUnit: 100f,
                extrude: 0,
                meshType: SpriteMeshType.FullRect);
            s_circle.name = "BitGrid_Circle";
            s_circle.hideFlags = HideFlags.HideAndDontSave;
            return s_circle;
        }

        /// <summary>
        /// Alpha at (x, y) for a rounded rectangle of the given size and corner radius.
        /// One-pixel analytic anti-aliasing via clamped distance from the nearest corner center.
        /// </summary>
        private static float RoundedAlpha(int x, int y, int size, int radius)
        {
            int rr = radius;
            float cx, cy;

            if (x < rr && y < rr) { cx = rr; cy = rr; }
            else if (x >= size - rr && y < rr) { cx = size - rr; cy = rr; }
            else if (x < rr && y >= size - rr) { cx = rr; cy = size - rr; }
            else if (x >= size - rr && y >= size - rr) { cx = size - rr; cy = size - rr; }
            else { return 1f; }

            float dx = x - cx + 0.5f;
            float dy = y - cy + 0.5f;
            float dist = Mathf.Sqrt(dx * dx + dy * dy);
            return Mathf.Clamp01(rr - dist + 0.5f);
        }
    }
}
