using UnityEngine;

namespace BitGrid.Services
{
    /// <summary>
    /// Thin wrapper around <see cref="Handheld.Vibrate"/> exposing intent-named
    /// helpers (<see cref="Light"/>, <see cref="Medium"/>, <see cref="Heavy"/>).
    ///
    /// On desktop / editor the calls are no-ops. On iOS / Android they fall back
    /// to <see cref="Handheld.Vibrate"/>. Differentiating intensity requires a
    /// native plugin (TapticEngine on iOS, Vibrator on Android); for now all
    /// tiers route to the same vibration so we can inject richer bindings later
    /// without changing call sites.
    /// </summary>
    public static class HapticService
    {
        public static bool Enabled { get; set; } = true;

        public static void Light()  => Vibrate();
        public static void Medium() => Vibrate();
        public static void Heavy()  => Vibrate();

        private static void Vibrate()
        {
            if (!Enabled) return;
#if UNITY_IOS || UNITY_ANDROID
            if (!Application.isEditor) Handheld.Vibrate();
#endif
        }
    }
}
