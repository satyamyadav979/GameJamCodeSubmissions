using UnityEngine;

namespace BitGrid.Services
{
    /// <summary>
    /// Lightweight audio service that generates short sine-wave beeps at runtime
    /// so the game has audible feedback without shipping any audio assets. Clips
    /// are cached after the first <see cref="Initialize"/> call.
    ///
    /// Every public Play method is safe to call before <see cref="Initialize"/>;
    /// it will lazily initialize on first use. Set <see cref="Muted"/> to true to
    /// silence everything (e.g. bound to a UI toggle).
    /// </summary>
    public static class AudioService
    {
        private static AudioSource _source;
        private static AudioClip _click;
        private static AudioClip _correct;
        private static AudioClip _wrong;
        private static AudioClip _win;
        private static AudioClip _hint;
        private static bool _initialized;

        public static bool Muted { get; set; }

        public static void Initialize()
        {
            if (_initialized) return;

            var go = new GameObject("[AudioService]");
            Object.DontDestroyOnLoad(go);
            _source = go.AddComponent<AudioSource>();
            _source.playOnAwake = false;
            _source.spatialBlend = 0f;

            _click   = MakeBeep(freq: 880f,  durationSec: 0.06f, volume: 0.20f);
            _correct = MakeBeep(freq: 1320f, durationSec: 0.14f, volume: 0.28f);
            _wrong   = MakeBeep(freq: 180f,  durationSec: 0.28f, volume: 0.32f);
            _hint    = MakeBeep(freq: 660f,  durationSec: 0.12f, volume: 0.22f);
            _win     = MakeChord(
                freqs: new[] { 523.25f, 659.25f, 783.99f, 1046.5f },
                durationSec: 0.55f, volume: 0.30f);

            _initialized = true;
        }

        public static void PlayClick()   => Play(_click);
        public static void PlayCorrect() => Play(_correct);
        public static void PlayWrong()   => Play(_wrong);
        public static void PlayWin()     => Play(_win);
        public static void PlayHint()    => Play(_hint);

        private static void Play(AudioClip clip)
        {
            if (!_initialized) Initialize();
            if (Muted || clip == null || _source == null) return;
            _source.PlayOneShot(clip);
        }

        /// <summary>
        /// Synthesizes a single sine tone with a fast attack + exponential decay
        /// envelope so consecutive beeps don't pop or click on buffer boundaries.
        /// </summary>
        private static AudioClip MakeBeep(float freq, float durationSec, float volume)
        {
            const int sampleRate = 44100;
            int samples = Mathf.Max(1, Mathf.CeilToInt(durationSec * sampleRate));
            var data = new float[samples];
            for (int i = 0; i < samples; i++)
            {
                float t = i / (float)sampleRate;
                float env = Mathf.Clamp01(t * 40f) * Mathf.Exp(-t * 8f);
                data[i] = Mathf.Sin(2f * Mathf.PI * freq * t) * env * volume;
            }
            var clip = AudioClip.Create($"bg_beep_{freq:F0}", samples, 1, sampleRate, false);
            clip.SetData(data, 0);
            return clip;
        }

        /// <summary>
        /// Superposition of sine tones, normalised so the peak amplitude stays
        /// bounded regardless of how many partials are stacked.
        /// </summary>
        private static AudioClip MakeChord(float[] freqs, float durationSec, float volume)
        {
            const int sampleRate = 44100;
            int samples = Mathf.Max(1, Mathf.CeilToInt(durationSec * sampleRate));
            var data = new float[samples];
            float invN = 1f / Mathf.Max(1, freqs.Length);
            for (int i = 0; i < samples; i++)
            {
                float t = i / (float)sampleRate;
                float env = Mathf.Clamp01(t * 20f) * Mathf.Exp(-t * 2.5f);
                float s = 0f;
                for (int k = 0; k < freqs.Length; k++)
                    s += Mathf.Sin(2f * Mathf.PI * freqs[k] * t);
                data[i] = s * invN * env * volume;
            }
            var clip = AudioClip.Create("bg_chord", samples, 1, sampleRate, false);
            clip.SetData(data, 0);
            return clip;
        }
    }
}
