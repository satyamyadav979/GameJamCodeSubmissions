using System;
using BitGrid.Core;
using UnityEngine;

namespace BitGrid.Data
{
    /// <summary>
    /// Serializable, reproducible snapshot of a single puzzle. Unlike a pure (size,
    /// difficulty, seed) tuple, this preserves the exact board across future generator
    /// tweaks by freezing the solution + locks + target-visibility masks as plain 0/1
    /// strings. Authored via the <c>BitGrid &gt; Regenerate Sample Levels</c> editor
    /// menu and consumed at runtime via <see cref="ToPuzzle"/>.
    /// </summary>
    [CreateAssetMenu(
        fileName = "Level",
        menuName = "BitGrid/Level Data",
        order = 10)]
    public sealed class LevelData : ScriptableObject
    {
        [Tooltip("Human-readable label shown in level pickers / debug logs.")]
        public string displayName = "Untitled";

        [Range(2, 8)] public int size = 4;
        public WeightingMode mode = WeightingMode.PositionalBinary;
        public PuzzleDifficulty difficulty = PuzzleDifficulty.Easy;

        [Tooltip("Generator seed used to produce this level (0 if hand-authored).")]
        public int seed;

        [Header("Frozen board (row-major)")]
        [Tooltip("Solution bits, row-major, length = size*size. Characters: '0' or '1'.")]
        [TextArea(2, 6)] public string solutionBits = string.Empty;

        [Tooltip("Locked/given mask, row-major, length = size*size. '1' = locked to solution.")]
        [TextArea(2, 6)] public string lockedBits = string.Empty;

        [Tooltip("Per-row target visibility, length = size. '1' = target shown; '0' = hidden.")]
        public string rowVisibleBits = string.Empty;

        [Tooltip("Per-column target visibility, length = size. '1' = target shown; '0' = hidden.")]
        public string colVisibleBits = string.Empty;

        /// <summary>
        /// Materialize this level into a live <see cref="Puzzle"/>. Throws if the
        /// serialized bit strings don't match <see cref="size"/>.
        /// </summary>
        public Puzzle ToPuzzle()
        {
            int n = size;
            int expectedGridLen = n * n;
            ValidateBitString(solutionBits, expectedGridLen, nameof(solutionBits));
            ValidateBitString(lockedBits, expectedGridLen, nameof(lockedBits));
            ValidateBitString(rowVisibleBits, n, nameof(rowVisibleBits));
            ValidateBitString(colVisibleBits, n, nameof(colVisibleBits));

            var solution = new CellState[n, n];
            var locked = new bool[n, n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    int idx = i * n + j;
                    solution[i, j] = solutionBits[idx] == '1' ? CellState.One : CellState.Zero;
                    locked[i, j] = lockedBits[idx] == '1';
                }
            }

            var rowVisible = new bool[n];
            var colVisible = new bool[n];
            for (int i = 0; i < n; i++)
            {
                rowVisible[i] = rowVisibleBits[i] == '1';
                colVisible[i] = colVisibleBits[i] == '1';
            }

            return new Puzzle(n, mode, solution, locked,
                rowTargetVisible: rowVisible, colTargetVisible: colVisible);
        }

        /// <summary>
        /// Snapshot a live <see cref="Puzzle"/> into this asset's serialized fields.
        /// Useful for editor-time "regenerate" flows.
        /// </summary>
        public void CaptureFromPuzzle(Puzzle puzzle, int generatorSeed, string display = null)
        {
            if (puzzle == null) throw new ArgumentNullException(nameof(puzzle));

            size = puzzle.Size;
            mode = puzzle.Mode;
            seed = generatorSeed;
            if (!string.IsNullOrEmpty(display)) displayName = display;

            var sol = new char[size * size];
            var lk = new char[size * size];
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    int idx = i * size + j;
                    sol[idx] = puzzle.Solution[i, j] == CellState.One ? '1' : '0';
                    lk[idx] = puzzle.Locked[i, j] ? '1' : '0';
                }
            }

            var rv = new char[size];
            var cv = new char[size];
            for (int i = 0; i < size; i++)
            {
                rv[i] = puzzle.RowTargetVisible[i] ? '1' : '0';
                cv[i] = puzzle.ColTargetVisible[i] ? '1' : '0';
            }

            solutionBits = new string(sol);
            lockedBits = new string(lk);
            rowVisibleBits = new string(rv);
            colVisibleBits = new string(cv);
        }

        private static void ValidateBitString(string s, int expectedLength, string field)
        {
            if (s == null || s.Length != expectedLength)
                throw new InvalidOperationException(
                    $"LevelData.{field} length mismatch: expected {expectedLength}, got {(s?.Length ?? 0)}.");
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] != '0' && s[i] != '1')
                    throw new InvalidOperationException(
                        $"LevelData.{field} contains non-binary char '{s[i]}' at index {i}.");
            }
        }
    }
}
