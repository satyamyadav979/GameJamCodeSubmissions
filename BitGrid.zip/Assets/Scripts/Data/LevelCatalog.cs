using System.Collections.Generic;
using System.Linq;
using BitGrid.Core;
using UnityEngine;

namespace BitGrid.Data
{
    /// <summary>
    /// Runtime loader for the set of <see cref="LevelData"/> assets that ship with
    /// the game. Discovers every asset under <c>Resources/Levels/</c> and caches
    /// them in difficulty-then-name order so the in-game picker can list and
    /// navigate them deterministically.
    /// </summary>
    public static class LevelCatalog
    {
        private const string ResourcesFolder = "Levels";

        private static LevelData[] s_levels;

        /// <summary>Every level asset shipped with the game, in presentation order.</summary>
        public static IReadOnlyList<LevelData> All
        {
            get
            {
                if (s_levels == null) Load();
                return s_levels;
            }
        }

        /// <summary>Reload the catalog from disk (editor-only use; runtime is cached).</summary>
        public static void Reload()
        {
            s_levels = null;
            Load();
        }

        /// <summary>Index of <paramref name="level"/> in <see cref="All"/>, or -1 if not present.</summary>
        public static int IndexOf(LevelData level)
        {
            if (level == null) return -1;
            var all = All;
            for (int i = 0; i < all.Count; i++) if (all[i] == level) return i;
            return -1;
        }

        /// <summary>
        /// Return the level immediately after <paramref name="current"/>, wrapping to the
        /// start when the catalog is exhausted. Returns null when the catalog is empty.
        /// </summary>
        public static LevelData Next(LevelData current)
        {
            var all = All;
            if (all.Count == 0) return null;
            int i = IndexOf(current);
            if (i < 0) return all[0];
            return all[(i + 1) % all.Count];
        }

        private static void Load()
        {
            var loaded = Resources.LoadAll<LevelData>(ResourcesFolder) ?? System.Array.Empty<LevelData>();
            s_levels = loaded
                .OrderBy(l => (int)l.difficulty)
                .ThenBy(l => l.displayName, System.StringComparer.Ordinal)
                .ToArray();
        }

        /// <summary>Convenience: filter levels by difficulty.</summary>
        public static IEnumerable<LevelData> ByDifficulty(PuzzleDifficulty difficulty)
        {
            var all = All;
            for (int i = 0; i < all.Count; i++)
                if (all[i].difficulty == difficulty) yield return all[i];
        }
    }
}
