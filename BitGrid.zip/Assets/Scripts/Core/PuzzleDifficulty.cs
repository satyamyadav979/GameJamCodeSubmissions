namespace BitGrid.Core
{
    /// <summary>
    /// Controls how many cells are pre-revealed (locked) when a puzzle is generated.
    /// </summary>
    public enum PuzzleDifficulty : byte
    {
        Easy = 0,   // ~70% of cells locked to their correct value
        Medium = 1, // ~40-50% locked
        Hard = 2,   // 0% locked (empty grid)
    }
}
