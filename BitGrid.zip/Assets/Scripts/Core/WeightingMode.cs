namespace BitGrid.Core
{
    /// <summary>
    /// How a filled cell contributes to its row and column sum.
    ///
    /// <para>
    /// <see cref="PositionalBinary"/>: cell (i, j) contributes 2^j to its row sum and
    /// 2^i to its column sum. Each row then reads as a binary number whose value is the
    /// row target; each column likewise. Because the row target uniquely decodes the
    /// row's bits, puzzles in this mode are effectively "convert decimal to binary"
    /// exercises and the generator emits them with zero locks so the player fills in
    /// the bits themselves. Column targets act as a redundant consistency check. This
    /// is the default for BitGrid's on-theme gameplay.
    /// </para>
    ///
    /// <para>
    /// <see cref="UnitCount"/>: each filled cell adds 1 to its row and column sums.
    /// Targets become popcount constraints, which admit many valid cell patterns per
    /// row and produce real cross-axis puzzle tension. Useful for deduction-based
    /// levels and the hint engine.
    /// </para>
    /// </summary>
    public enum WeightingMode : byte
    {
        UnitCount = 0,
        PositionalBinary = 1,
    }
}
