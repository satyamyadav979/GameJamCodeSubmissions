using System;

namespace BitGrid.Core
{
    /// <summary>
    /// Runtime model of a single puzzle instance. Owns the ground-truth solution,
    /// the player's current board, the locked mask, the row/column targets, and
    /// cached row/column sums that update in O(1) per toggle.
    /// </summary>
    public sealed class Puzzle
    {
        public int Size { get; }
        public WeightingMode Mode { get; }

        /// <summary>Ground-truth solution; never mutated after construction.</summary>
        public CellState[,] Solution { get; }

        /// <summary>Player-visible board. Initialized from Locked+Solution; mutated via Toggle/ResetToLocked.</summary>
        public CellState[,] Current { get; }

        /// <summary>Cells the player cannot change. Their values mirror Solution at those indices.</summary>
        public bool[,] Locked { get; }

        public int[] RowTargets { get; }
        public int[] ColTargets { get; }

        /// <summary>
        /// Per-row flag: true when the row's target number is shown to the player,
        /// false when it is hidden (rendered as "?") and must be deduced from column
        /// constraints + locked givens. Defaults to all-visible.
        /// </summary>
        public bool[] RowTargetVisible { get; }

        /// <summary>
        /// Per-column flag: true when the column's target number is shown to the
        /// player, false when it must be deduced. Defaults to all-visible.
        /// </summary>
        public bool[] ColTargetVisible { get; }

        /// <summary>Weighted sum of Current along each row; kept in sync by Toggle.</summary>
        public int[] RowSums { get; }

        /// <summary>Weighted sum of Current along each column; kept in sync by Toggle.</summary>
        public int[] ColSums { get; }

        public Puzzle(int size, WeightingMode mode, CellState[,] solution, bool[,] locked)
            : this(size, mode, solution, locked, rowTargetVisible: null, colTargetVisible: null) { }

        public Puzzle(
            int size,
            WeightingMode mode,
            CellState[,] solution,
            bool[,] locked,
            bool[] rowTargetVisible,
            bool[] colTargetVisible)
        {
            if (size <= 0) throw new ArgumentOutOfRangeException(nameof(size));
            if (solution == null) throw new ArgumentNullException(nameof(solution));
            if (locked == null) throw new ArgumentNullException(nameof(locked));
            if (solution.GetLength(0) != size || solution.GetLength(1) != size)
                throw new ArgumentException("Solution dimensions mismatch size.", nameof(solution));
            if (locked.GetLength(0) != size || locked.GetLength(1) != size)
                throw new ArgumentException("Locked dimensions mismatch size.", nameof(locked));
            if (rowTargetVisible != null && rowTargetVisible.Length != size)
                throw new ArgumentException("RowTargetVisible length mismatch size.", nameof(rowTargetVisible));
            if (colTargetVisible != null && colTargetVisible.Length != size)
                throw new ArgumentException("ColTargetVisible length mismatch size.", nameof(colTargetVisible));

            Size = size;
            Mode = mode;
            Solution = solution;
            Locked = locked;

            Current = new CellState[size, size];
            RowTargets = new int[size];
            ColTargets = new int[size];
            RowSums = new int[size];
            ColSums = new int[size];

            RowTargetVisible = rowTargetVisible ?? DefaultAllTrue(size);
            ColTargetVisible = colTargetVisible ?? DefaultAllTrue(size);

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (solution[i, j] == CellState.One)
                    {
                        RowTargets[i] += RowWeight(i, j);
                        ColTargets[j] += ColWeight(i, j);
                    }

                    if (locked[i, j])
                    {
                        Current[i, j] = solution[i, j];
                        if (solution[i, j] == CellState.One)
                        {
                            RowSums[i] += RowWeight(i, j);
                            ColSums[j] += ColWeight(i, j);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Contribution of a filled cell (i, j) to its row sum under the current mode.
        /// UnitCount -> 1; PositionalBinary -> 2^j so the row reads as a binary number
        /// with column index j as the bit position.
        /// </summary>
        public int RowWeight(int i, int j)
        {
            return Mode switch
            {
                WeightingMode.UnitCount => 1,
                WeightingMode.PositionalBinary => 1 << j,
                _ => 1,
            };
        }

        /// <summary>
        /// Contribution of a filled cell (i, j) to its column sum under the current mode.
        /// UnitCount -> 1; PositionalBinary -> 2^i so the column reads as a binary number
        /// with row index i as the bit position.
        /// </summary>
        public int ColWeight(int i, int j)
        {
            return Mode switch
            {
                WeightingMode.UnitCount => 1,
                WeightingMode.PositionalBinary => 1 << i,
                _ => 1,
            };
        }

        /// <summary>
        /// Flip cell (i, j) between 0 and 1, updating cached row/column sums in O(1).
        /// No-op if the cell is locked or indices are out of range.
        /// Returns the new state; returns the old state unchanged if the toggle was rejected.
        /// </summary>
        public CellState Toggle(int i, int j)
        {
            if (i < 0 || i >= Size || j < 0 || j >= Size) return CellState.Zero;
            if (Locked[i, j]) return Current[i, j];

            int rw = RowWeight(i, j);
            int cw = ColWeight(i, j);
            if (Current[i, j] == CellState.Zero)
            {
                Current[i, j] = CellState.One;
                RowSums[i] += rw;
                ColSums[j] += cw;
            }
            else
            {
                Current[i, j] = CellState.Zero;
                RowSums[i] -= rw;
                ColSums[j] -= cw;
            }
            return Current[i, j];
        }

        /// <summary>Restore every non-locked cell to Zero and refresh cached sums.</summary>
        public void ResetToLocked()
        {
            Array.Clear(RowSums, 0, RowSums.Length);
            Array.Clear(ColSums, 0, ColSums.Length);

            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    if (Locked[i, j])
                    {
                        Current[i, j] = Solution[i, j];
                        if (Current[i, j] == CellState.One)
                        {
                            RowSums[i] += RowWeight(i, j);
                            ColSums[j] += ColWeight(i, j);
                        }
                    }
                    else
                    {
                        Current[i, j] = CellState.Zero;
                    }
                }
            }
        }

        /// <summary>True when every row and column sum equals its target.</summary>
        public bool IsSolved()
        {
            for (int i = 0; i < Size; i++)
            {
                if (RowSums[i] != RowTargets[i]) return false;
                if (ColSums[i] != ColTargets[i]) return false;
            }
            return true;
        }

        /// <summary>
        /// Defensive recompute of RowSums/ColSums from Current. Normally unnecessary
        /// because Toggle keeps them in sync; useful after bulk edits or deserialization.
        /// </summary>
        public void RecalculateSums()
        {
            Array.Clear(RowSums, 0, RowSums.Length);
            Array.Clear(ColSums, 0, ColSums.Length);
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    if (Current[i, j] == CellState.One)
                    {
                        RowSums[i] += RowWeight(i, j);
                        ColSums[j] += ColWeight(i, j);
                    }
                }
            }
        }

        private static bool[] DefaultAllTrue(int size)
        {
            var arr = new bool[size];
            for (int i = 0; i < size; i++) arr[i] = true;
            return arr;
        }
    }
}
