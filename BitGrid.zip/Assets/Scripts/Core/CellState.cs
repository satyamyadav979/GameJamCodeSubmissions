namespace BitGrid.Core
{
    /// <summary>
    /// Binary state of a single grid cell.
    /// </summary>
    public enum CellState : byte
    {
        Zero = 0,
        One = 1,
    }
}
