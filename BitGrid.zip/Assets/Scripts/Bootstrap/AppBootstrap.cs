using BitGrid.Core;
using BitGrid.Data;
using BitGrid.Gameplay;
using BitGrid.Generation;
using BitGrid.Services;
using BitGrid.UI;
using UnityEngine;

namespace BitGrid.Bootstrap
{
    /// <summary>
    /// Entry point for BitGrid. Self-instantiates via RuntimeInitializeOnLoadMethod
    /// so no scene setup is required - the user can open Game.unity and press Play.
    ///
    /// Responsibilities across phases:
    ///   - Phase 3: build the Canvas hierarchy and show the skeleton UI.
    ///   - Phase 4 (now): generate a puzzle and hand it to GridManager so the grid is interactive.
    ///   - Phase 5+: wire Reset/Hint/Confirm buttons through GameManager.
    /// </summary>
    [DefaultExecutionOrder(-1000)]
    public sealed class AppBootstrap : MonoBehaviour
    {
        public static AppBootstrap Instance { get; private set; }
        public UIRefs UI { get; private set; }
        public ThemePalette Palette { get; private set; }
        public GridManager Grid { get; private set; }
        public GameManager Game { get; private set; }

        [Header("Puzzle defaults (will move to LevelData in Phase 8)")]
        [SerializeField] private int startingSize = 4;
        [SerializeField] private PuzzleDifficulty startingDifficulty = PuzzleDifficulty.Medium;
        [SerializeField] private WeightingMode weightingMode = WeightingMode.PositionalBinary;
        [SerializeField] private int startingSeed = 42;

        [Header("Accessibility")]
        [Tooltip("If true, start in high-contrast palette (overridden by paletteOverride if set).")]
        [SerializeField] private bool useHighContrast = false;

        [Header("Optional overrides")]
        [SerializeField] private ThemePalette paletteOverride;
        [Tooltip("If set, the game boots this exact level instead of generating a random one.")]
        [SerializeField] private LevelData startingLevel;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void AutoCreate()
        {
            if (Instance != null) return;

            var go = new GameObject("[Bootstrap]");
            DontDestroyOnLoad(go);
            go.AddComponent<AppBootstrap>();
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;

            Application.targetFrameRate = 60;
            Input.multiTouchEnabled = false;

            AudioService.Initialize();

            Palette = paletteOverride != null
                ? paletteOverride
                : (useHighContrast ? ThemePalette.HighContrast : ThemePalette.Default);
            UI = UIBuilder.Build(Palette);
        }

        private void Start()
        {
            var gridGo = new GameObject("[GridManager]");
            gridGo.transform.SetParent(transform, worldPositionStays: false);
            Grid = gridGo.AddComponent<GridManager>();

            Puzzle puzzle;
            if (startingLevel != null)
            {
                puzzle = startingLevel.ToPuzzle();
                startingSize = startingLevel.size;
                startingDifficulty = startingLevel.difficulty;
                weightingMode = startingLevel.mode;
                startingSeed = startingLevel.seed;
            }
            else
            {
                puzzle = PuzzleGenerator.Generate(
                    startingSize, startingDifficulty, weightingMode, startingSeed);
            }
            Grid.Build(puzzle, UI, Palette);

            var gameGo = new GameObject("[GameManager]");
            gameGo.transform.SetParent(transform, worldPositionStays: false);
            Game = gameGo.AddComponent<GameManager>();
            Game.Initialize(UI, Palette, Grid,
                startingSize, startingDifficulty, weightingMode, startingSeed);
            if (startingLevel != null) Game.AttachCurrentLevel(startingLevel);

            WireAccessibilityButton();

            Debug.Log($"[BitGrid] Puzzle loaded: size={puzzle.Size}, mode={puzzle.Mode}, " +
                      $"difficulty={startingDifficulty}, seed={startingSeed}.");
        }

        /// <summary>
        /// Swap the entire UI palette. Destroys and rebuilds the Canvas hierarchy,
        /// rebuilds the grid for the same puzzle (preserving player state), and
        /// re-wires the GameManager to the fresh UI references.
        /// </summary>
        public void SetPalette(ThemePalette newPalette)
        {
            if (newPalette == null || newPalette == Palette) return;

            var currentPuzzle = Grid != null ? Grid.Puzzle : null;

            if (UI != null)
            {
                Destroy(UI.gameObject);
                UI = null;
            }

            Palette = newPalette;
            UI = UIBuilder.Build(Palette);

            if (currentPuzzle != null && Grid != null)
                Grid.Build(currentPuzzle, UI, Palette);

            if (Game != null) Game.OnUIReplaced(UI, Palette);

            WireAccessibilityButton();
        }

        /// <summary>Flip between the Default palette and <see cref="ThemePalette.HighContrast"/>.</summary>
        public void TogglePalette()
        {
            var next = Palette == ThemePalette.HighContrast
                ? ThemePalette.Default
                : ThemePalette.HighContrast;
            SetPalette(next);
        }

        private void WireAccessibilityButton()
        {
            if (UI == null || UI.AccessibilityButton == null) return;
            UI.AccessibilityButton.onClick.RemoveListener(TogglePalette);
            UI.AccessibilityButton.onClick.AddListener(TogglePalette);
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }
    }
}
