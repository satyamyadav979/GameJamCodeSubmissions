using System.IO;
using BitGrid.Core;
using BitGrid.Data;
using BitGrid.Generation;
using UnityEditor;
using UnityEngine;

namespace BitGrid.EditorTools
{
    /// <summary>
    /// Editor-only authoring helpers. The "Regenerate Sample Levels" menu produces
    /// a curated set of 9 <see cref="LevelData"/> assets (3 Easy, 3 Medium, 3 Hard)
    /// under <c>Assets/Data/Levels/</c>. Each level is produced by the shared
    /// <see cref="PuzzleGenerator"/> with a fixed seed, then frozen into its asset
    /// so the level survives future generator tweaks.
    /// </summary>
    public static class LevelAuthoring
    {
        // Must live under a Resources folder so LevelCatalog.LoadAll can discover
        // the assets at runtime via Resources.LoadAll<LevelData>("Levels").
        private const string LevelsFolder = "Assets/Resources/Levels";

        private static readonly (PuzzleDifficulty difficulty, int seed, string displayName)[] SampleLevels =
        {
            (PuzzleDifficulty.Easy,   101, "Easy 1"),
            (PuzzleDifficulty.Easy,   202, "Easy 2"),
            (PuzzleDifficulty.Easy,   303, "Easy 3"),
            (PuzzleDifficulty.Medium, 404, "Medium 1"),
            (PuzzleDifficulty.Medium, 505, "Medium 2"),
            (PuzzleDifficulty.Medium, 606, "Medium 3"),
            (PuzzleDifficulty.Hard,   707, "Hard 1"),
            (PuzzleDifficulty.Hard,   808, "Hard 2"),
            (PuzzleDifficulty.Hard,   909, "Hard 3"),
        };

        [MenuItem("BitGrid/Regenerate Sample Levels")]
        public static void RegenerateSampleLevels()
        {
            EnsureFolder(LevelsFolder);

            int overwrites = 0, creations = 0;
            foreach (var entry in SampleLevels)
            {
                var cfg = PuzzleGenerator.PositionalBinaryDifficultyConfig[(int)entry.difficulty];
                var puzzle = PuzzleGenerator.Generate(
                    size: cfg.size,
                    difficulty: entry.difficulty,
                    mode: WeightingMode.PositionalBinary,
                    seed: entry.seed);

                string assetPath = $"{LevelsFolder}/{SanitizeFileName(entry.displayName)}.asset";
                var existing = AssetDatabase.LoadAssetAtPath<LevelData>(assetPath);
                LevelData data;
                if (existing != null)
                {
                    data = existing;
                    overwrites++;
                }
                else
                {
                    data = ScriptableObject.CreateInstance<LevelData>();
                    AssetDatabase.CreateAsset(data, assetPath);
                    creations++;
                }

                data.difficulty = entry.difficulty;
                data.CaptureFromPuzzle(puzzle, entry.seed, entry.displayName);
                EditorUtility.SetDirty(data);
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log($"[BitGrid] Regenerated sample levels: {creations} created, {overwrites} updated.");
        }

        private static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;

            string[] parts = path.Split('/');
            string acc = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = $"{acc}/{parts[i]}";
                if (!AssetDatabase.IsValidFolder(next))
                    AssetDatabase.CreateFolder(acc, parts[i]);
                acc = next;
            }
        }

        private static string SanitizeFileName(string name)
        {
            var invalid = Path.GetInvalidFileNameChars();
            var sb = new System.Text.StringBuilder(name.Length);
            foreach (char c in name)
            {
                bool safe = c != ' ' && System.Array.IndexOf(invalid, c) < 0;
                sb.Append(safe ? c : '_');
            }
            return sb.ToString();
        }
    }
}
