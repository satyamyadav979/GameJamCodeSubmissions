using BitGrid.Core;

namespace BitGrid.Gameplay
{
    /// <summary>
    /// Produces the next suggested move for a given puzzle state.
    ///
    /// <para>
    /// <see cref="WeightingMode.PositionalBinary"/>: targets decode uniquely per axis,
    /// so the engine teaches one bit at a time. It finds the first row whose running
    /// sum does not equal its target, XORs them to locate the lowest mismatched bit,
    /// and returns a hint naming that cell along with a plain-English reason referencing
    /// the bit power and its decimal weight. Columns are used as a fallback in the rare
    /// case every row is satisfied but a column is not (can happen mid-edit if the player
    /// over-fills a cell that satisfies its row but breaks a column).
    /// </para>
    ///
    /// <para>
    /// <see cref="WeightingMode.UnitCount"/>: the engine does not yet run full deductive
    /// reasoning. It falls back to comparing <see cref="Puzzle.Current"/> with
    /// <see cref="Puzzle.Solution"/> and returning the first non-locked mismatch with a
    /// short reason. Phase 7+ can replace this with a logical-step deducer using the
    /// Solver's constraint propagation.
    /// </para>
    /// </summary>
    public static class HintEngine
    {
        public static Hint GetNext(Puzzle puzzle)
        {
            if (puzzle == null) return Hint.None;
            if (puzzle.IsSolved()) return Hint.None;

            return puzzle.Mode switch
            {
                WeightingMode.PositionalBinary => BinaryHint(puzzle),
                _ => SolutionPeekHint(puzzle),
            };
        }

        private static Hint BinaryHint(Puzzle puzzle)
        {
            int n = puzzle.Size;

            // Rows first: each row's target uniquely decodes, so the lowest mismatched
            // bit tells the player exactly which cell to toggle.
            for (int i = 0; i < n; i++)
            {
                int diff = puzzle.RowSums[i] ^ puzzle.RowTargets[i];
                if (diff == 0) continue;

                for (int j = 0; j < n; j++)
                {
                    int bit = 1 << j;
                    if ((diff & bit) == 0) continue;
                    if (puzzle.Locked[i, j]) continue;

                    bool targetOn = (puzzle.RowTargets[i] & bit) != 0;
                    var desired = targetOn ? CellState.One : CellState.Zero;
                    string reason = FormatRowReason(i, j, bit, puzzle.RowTargets[i], targetOn);
                    return new Hint(i, j, desired, reason);
                }
            }

            // Column fallback (very rare; typically implied by rows).
            for (int j = 0; j < n; j++)
            {
                int diff = puzzle.ColSums[j] ^ puzzle.ColTargets[j];
                if (diff == 0) continue;

                for (int i = 0; i < n; i++)
                {
                    int bit = 1 << i;
                    if ((diff & bit) == 0) continue;
                    if (puzzle.Locked[i, j]) continue;

                    bool targetOn = (puzzle.ColTargets[j] & bit) != 0;
                    var desired = targetOn ? CellState.One : CellState.Zero;
                    string reason = FormatColReason(i, j, bit, puzzle.ColTargets[j], targetOn);
                    return new Hint(i, j, desired, reason);
                }
            }

            return Hint.None;
        }

        private static Hint SolutionPeekHint(Puzzle puzzle)
        {
            int n = puzzle.Size;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (puzzle.Locked[i, j]) continue;
                    if (puzzle.Current[i, j] == puzzle.Solution[i, j]) continue;

                    bool shouldOn = puzzle.Solution[i, j] == CellState.One;
                    var desired = shouldOn ? CellState.One : CellState.Zero;
                    string reason = shouldOn
                        ? $"Fill cell (R{i + 1}, C{j + 1}) to progress toward the target."
                        : $"Clear cell (R{i + 1}, C{j + 1}) - it shouldn't be filled.";
                    return new Hint(i, j, desired, reason);
                }
            }
            return Hint.None;
        }

        private static string FormatRowReason(int row, int col, int bitValue, int target, bool targetOn)
        {
            int power = LowestSetBitIndex(bitValue);
            return targetOn
                ? $"Row {row + 1} target {target}: bit 2^{power} = {bitValue} is missing. Turn ON cell (R{row + 1}, C{col + 1})."
                : $"Row {row + 1} target {target}: bit 2^{power} = {bitValue} should be OFF. Turn OFF cell (R{row + 1}, C{col + 1}).";
        }

        private static string FormatColReason(int row, int col, int bitValue, int target, bool targetOn)
        {
            int power = LowestSetBitIndex(bitValue);
            return targetOn
                ? $"Column {col + 1} target {target}: bit 2^{power} = {bitValue} is missing. Turn ON cell (R{row + 1}, C{col + 1})."
                : $"Column {col + 1} target {target}: bit 2^{power} = {bitValue} should be OFF. Turn OFF cell (R{row + 1}, C{col + 1}).";
        }

        private static int LowestSetBitIndex(int value)
        {
            int k = 0;
            while (value > 1) { value >>= 1; k++; }
            return k;
        }
    }
}
