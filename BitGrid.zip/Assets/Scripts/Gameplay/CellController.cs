using System;
using BitGrid.Core;
using BitGrid.UI;
using BitGrid.Utils;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BitGrid.Gameplay
{
    /// <summary>
    /// Visual + input behavior for a single grid cell. Holds its (row, col)
    /// coordinate pair, renders its CellState via background color, and emits
    /// <see cref="Clicked"/> when tapped. No game logic lives here - GridManager
    /// handles the toggle and pushes the new state back via <see cref="SetState"/>.
    /// </summary>
    [RequireComponent(typeof(RectTransform), typeof(Image), typeof(Button))]
    public sealed class CellController : MonoBehaviour
    {
        public int Row { get; private set; }
        public int Col { get; private set; }
        public bool IsLocked { get; private set; }

        public event Action<CellController> Clicked;

        private Image _background;
        private Button _button;
        private Image _lockPin;
        private TextMeshProUGUI _rowWeightLabel;
        private TextMeshProUGUI _colWeightLabel;
        private ThemePalette _palette;
        private Coroutine _popRoutine;

        /// <summary>
        /// Factory: create a cell GameObject under <paramref name="parent"/> and
        /// return the attached <see cref="CellController"/>.
        /// </summary>
        public static CellController Create(
            RectTransform parent, int row, int col, ThemePalette palette,
            int rowWeight, int colWeight, bool showWeights)
        {
            var go = new GameObject($"Cell_{row}_{col}",
                typeof(RectTransform), typeof(Image), typeof(Button), typeof(CellController));
            go.transform.SetParent(parent, worldPositionStays: false);

            var ctrl = go.GetComponent<CellController>();
            ctrl.Initialize(row, col, palette);
            if (showWeights) ctrl.SetWeightHints(rowWeight, colWeight);
            return ctrl;
        }

        private void Initialize(int row, int col, ThemePalette palette)
        {
            Row = row;
            Col = col;
            _palette = palette;

            _background = GetComponent<Image>();
            _background.sprite = SpriteFactory.RoundedRect();
            _background.type = Image.Type.Sliced;
            _background.color = palette.cellOff;
            _background.raycastTarget = true;

            _button = GetComponent<Button>();
            _button.targetGraphic = _background;
            _button.transition = Selectable.Transition.ColorTint;

            var colors = _button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 1f, 1f, 0.95f);
            colors.pressedColor = new Color(0.9f, 0.9f, 0.9f, 1f);
            colors.selectedColor = Color.white;
            colors.disabledColor = new Color(1f, 1f, 1f, 1f);
            _button.colors = colors;

            _button.onClick.AddListener(OnClick);

            _lockPin = CreateLockPin(palette);
            _rowWeightLabel = CreateWeightLabel("RowWeight", isRow: true, palette);
            _colWeightLabel = CreateWeightLabel("ColWeight", isRow: false, palette);
        }

        /// <summary>
        /// Populate the two small in-cell bit-weight hints (row contribution 2^j
        /// on the top-left, column contribution 2^i on the bottom-right).
        /// </summary>
        public void SetWeightHints(int rowWeight, int colWeight)
        {
            if (_rowWeightLabel != null)
            {
                _rowWeightLabel.text = rowWeight.ToString();
                _rowWeightLabel.gameObject.SetActive(true);
            }
            if (_colWeightLabel != null)
            {
                _colWeightLabel.text = colWeight.ToString();
                _colWeightLabel.gameObject.SetActive(true);
            }
        }

        /// <summary>Update the cell's visual state and locked status.</summary>
        public void SetState(CellState state, bool locked, bool animate = false)
        {
            IsLocked = locked;
            _button.interactable = !locked;

            Color target;
            if (locked)
            {
                target = state == CellState.One ? _palette.cellOnLocked : _palette.cellOffLocked;
            }
            else
            {
                target = state == CellState.One ? _palette.cellOn : _palette.cellOff;
            }
            _background.color = target;

            if (_lockPin != null)
            {
                _lockPin.gameObject.SetActive(locked);
                if (locked)
                {
                    // Dot contrasts with cell fill: white dot on filled cells, dark dot on empty.
                    _lockPin.color = state == CellState.One
                        ? _palette.textOnAccent
                        : _palette.cellLockedPin;
                }
            }

            if (animate) PlayPop();
        }

        private TextMeshProUGUI CreateWeightLabel(string name, bool isRow, ThemePalette palette)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(transform, worldPositionStays: false);

            var rt = (RectTransform)go.transform;
            if (isRow)
            {
                // Top-left corner: row contribution (2^j, weight added to this cell's row).
                rt.anchorMin = new Vector2(0f, 1f);
                rt.anchorMax = new Vector2(0f, 1f);
                rt.pivot = new Vector2(0f, 1f);
                rt.anchoredPosition = new Vector2(6f, -4f);
            }
            else
            {
                // Bottom-right corner: column contribution (2^i, weight added to column).
                rt.anchorMin = new Vector2(1f, 0f);
                rt.anchorMax = new Vector2(1f, 0f);
                rt.pivot = new Vector2(1f, 0f);
                rt.anchoredPosition = new Vector2(-6f, 4f);
            }
            rt.sizeDelta = new Vector2(44f, 24f);

            var tmp = go.AddComponent<TextMeshProUGUI>();
            tmp.text = string.Empty;
            tmp.fontSize = 18f;
            tmp.alignment = isRow ? TextAlignmentOptions.TopLeft : TextAlignmentOptions.BottomRight;
            tmp.fontStyle = FontStyles.Bold;
            tmp.raycastTarget = false;
            // Translucent so it doesn't fight with cell state color.
            var tint = palette.textPrimary;
            tmp.color = new Color(tint.r, tint.g, tint.b, 0.35f);
            go.SetActive(false);
            return tmp;
        }

        private Image CreateLockPin(ThemePalette palette)
        {
            var go = new GameObject("LockPin", typeof(RectTransform), typeof(Image));
            go.transform.SetParent(transform, worldPositionStays: false);

            var rt = (RectTransform)go.transform;
            rt.anchorMin = new Vector2(1f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(1f, 1f);
            rt.sizeDelta = new Vector2(18f, 18f);
            rt.anchoredPosition = new Vector2(-10f, -10f);

            var img = go.GetComponent<Image>();
            img.sprite = SpriteFactory.Circle();
            img.color = palette.cellLockedPin;
            img.raycastTarget = false;

            go.SetActive(false);
            return img;
        }

        /// <summary>Trigger the pop animation without changing state (for hint pulses, etc.).</summary>
        public void PlayPop(float peakScale = 1.12f, float durationSeconds = 0.16f)
        {
            if (_popRoutine != null) StopCoroutine(_popRoutine);
            _popRoutine = StartCoroutine(UITween.Pop(transform, peakScale, durationSeconds));
        }

        /// <summary>
        /// Emphasize this cell for hint presentation. Runs several successive pops so
        /// the player's eye tracks to it even if the tooltip above is already being read.
        /// </summary>
        public void Highlight(int pulseCount = 3, float pulseDuration = 0.28f, float peakScale = 1.22f)
        {
            if (_popRoutine != null) StopCoroutine(_popRoutine);
            _popRoutine = StartCoroutine(HighlightRoutine(pulseCount, pulseDuration, peakScale));
        }

        private System.Collections.IEnumerator HighlightRoutine(int pulseCount, float pulseDuration, float peakScale)
        {
            for (int i = 0; i < pulseCount; i++)
            {
                yield return UITween.Pop(transform, peakScale, pulseDuration);
                yield return new UnityEngine.WaitForSecondsRealtime(0.08f);
            }
        }

        private void OnClick()
        {
            if (IsLocked) return;
            Clicked?.Invoke(this);
        }

        private void OnDestroy()
        {
            if (_button != null) _button.onClick.RemoveListener(OnClick);
        }
    }
}
