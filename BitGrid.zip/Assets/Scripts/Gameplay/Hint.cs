using BitGrid.Core;

namespace BitGrid.Gameplay
{
    /// <summary>
    /// A single actionable suggestion produced by <see cref="HintEngine"/>.
    /// <see cref="IsValid"/> is false when the engine has nothing to suggest
    /// (e.g. the puzzle is already solved or every non-locked diff requires a
    /// locked cell to change - which should not happen for well-formed puzzles).
    /// </summary>
    public readonly struct Hint
    {
        public readonly bool IsValid;
        public readonly int Row;
        public readonly int Col;
        public readonly CellState TargetState;
        public readonly string Reason;

        public Hint(int row, int col, CellState targetState, string reason)
        {
            IsValid = true;
            Row = row;
            Col = col;
            TargetState = targetState;
            Reason = reason;
        }

        public static Hint None => default;
    }
}
