using System;
using System.Collections;
using BitGrid.Core;
using BitGrid.Data;
using BitGrid.Generation;
using BitGrid.Services;
using BitGrid.UI;
using BitGrid.Utils;
using UnityEngine;
using UnityEngine.UI;

namespace BitGrid.Gameplay
{
    /// <summary>
    /// High-level game loop. Owns per-session state (Level, Moves, IsWon) and
    /// brokers input between the UI (Reset / Hint / Confirm / Next Level buttons)
    /// and the GridManager / Puzzle. Keeps UIRefs text fields in sync.
    ///
    /// Phase 5 scope:
    ///   - MOVES counter driven by GridManager.CellToggled
    ///   - Reset resets the player state and the move counter
    ///   - Confirm: solved -> show WinOverlay; else flash offending row/col labels + shake grid
    ///   - Next Level: regenerate a new puzzle and bump the level index
    ///   - Hint button logs a placeholder; real behavior lands in Phase 6
    /// </summary>
    public sealed class GameManager : MonoBehaviour
    {
        public int Level { get; private set; } = 1;
        public int Moves { get; private set; }
        public int HintsRemaining { get; private set; }
        public bool IsWon { get; private set; }

        public event Action<int> LevelChanged;
        public event Action<int> MovesChanged;
        public event Action<int> HintsChanged;

        [Header("Hints")]
        [SerializeField] private int maxHintsPerLevel = 5;
        [SerializeField] private float hintTooltipSeconds = 6f;

        private UIRefs _ui;
        private ThemePalette _palette;
        private GridManager _grid;

        private int _size;
        /// <summary>The difficulty the session started at; auto-ramp never goes below this.</summary>
        private PuzzleDifficulty _baselineDifficulty;
        /// <summary>The difficulty of the CURRENT random puzzle (after auto-ramp).</summary>
        private PuzzleDifficulty _difficulty;
        private WeightingMode _mode;
        private System.Random _seedRng;
        private int _currentSeed;

        /// <summary>
        /// When non-null the current puzzle was loaded from a catalog level. Next-level
        /// advances through the catalog; when null, new random puzzles are generated.
        /// </summary>
        private LevelData _currentLevel;

        private Coroutine _shakeRoutine;
        private Coroutine _tooltipRoutine;

        /// <summary>
        /// Initialize the manager with all collaborators and generation settings.
        /// Should be called exactly once by AppBootstrap after the GridManager has
        /// been constructed (but can be called before or after the first Build).
        /// </summary>
        public void Initialize(
            UIRefs ui,
            ThemePalette palette,
            GridManager grid,
            int size,
            PuzzleDifficulty difficulty,
            WeightingMode mode,
            int startingSeed)
        {
            _ui = ui ?? throw new ArgumentNullException(nameof(ui));
            _palette = palette ?? throw new ArgumentNullException(nameof(palette));
            _grid = grid ?? throw new ArgumentNullException(nameof(grid));

            _size = size;
            _baselineDifficulty = difficulty;
            _difficulty = difficulty;
            _mode = mode;
            _currentSeed = startingSeed;
            _seedRng = new System.Random(startingSeed == 0 ? Environment.TickCount : startingSeed);

            _grid.CellToggled += OnCellToggled;
            _grid.Solved += OnSolved;

            _ui.ResetButton.onClick.AddListener(OnResetPressed);
            _ui.ConfirmButton.onClick.AddListener(OnConfirmPressed);
            _ui.HintButton.onClick.AddListener(OnHintPressed);
            _ui.WinNextButton.onClick.AddListener(OnNextLevelPressed);
            if (_ui.LevelsButton != null) _ui.LevelsButton.onClick.AddListener(OpenLevelPicker);
            if (_ui.LevelPickerCloseButton != null) _ui.LevelPickerCloseButton.onClick.AddListener(CloseLevelPicker);

            HintsRemaining = maxHintsPerLevel;

            HideWinOverlay();
            HideTooltip();
            HideLevelPicker();
            RefreshStatsUI();
            RefreshHintBadge();
        }

        /// <summary>
        /// Called when AppBootstrap has destroyed and rebuilt the UI (e.g. on an
        /// accessibility palette swap). Re-wires this manager onto the new button
        /// instances while preserving session state (Level, Moves, HintsRemaining, IsWon).
        /// </summary>
        public void OnUIReplaced(UIRefs newUi, ThemePalette newPalette)
        {
            if (newUi == null) throw new ArgumentNullException(nameof(newUi));
            if (newPalette == null) throw new ArgumentNullException(nameof(newPalette));

            // Old buttons were destroyed with the old UIRoot; our cached coroutines
            // may still be alive but point at destroyed transforms, so clear them.
            _shakeRoutine = null;
            _tooltipRoutine = null;

            _ui = newUi;
            _palette = newPalette;

            _ui.ResetButton.onClick.AddListener(OnResetPressed);
            _ui.ConfirmButton.onClick.AddListener(OnConfirmPressed);
            _ui.HintButton.onClick.AddListener(OnHintPressed);
            _ui.WinNextButton.onClick.AddListener(OnNextLevelPressed);
            if (_ui.LevelsButton != null) _ui.LevelsButton.onClick.AddListener(OpenLevelPicker);
            if (_ui.LevelPickerCloseButton != null) _ui.LevelPickerCloseButton.onClick.AddListener(CloseLevelPicker);

            if (IsWon) ShowWinOverlay();
            else HideWinOverlay();
            HideTooltip();
            HideLevelPicker();
            RefreshStatsUI();
            RefreshHintBadge();
        }

        /// <summary>Load a fresh random puzzle. Clears any catalog-level association.</summary>
        public void LoadNextPuzzle()
        {
            _currentSeed = _seedRng.Next(1, int.MaxValue);
            _difficulty = DifficultyForLevel(Level);
            var puzzle = PuzzleGenerator.Generate(_size, _difficulty, _mode, _currentSeed);
            _currentLevel = null;
            _grid.Build(puzzle, _ui, _palette);

            Moves = 0;
            HintsRemaining = maxHintsPerLevel;
            IsWon = false;
            MovesChanged?.Invoke(Moves);
            HintsChanged?.Invoke(HintsRemaining);
            HideTooltip();
            RefreshStatsUI();
            RefreshHintBadge();
        }

        /// <summary>
        /// Record <paramref name="level"/> as the source of the CURRENT puzzle without
        /// rebuilding the grid. Called from AppBootstrap when the scene boots with a
        /// <see cref="LevelData"/> asset already supplied, so stats and Next Level
        /// behavior align with the loaded level.
        /// </summary>
        public void AttachCurrentLevel(LevelData level)
        {
            _currentLevel = level;
            RefreshStatsUI();
        }

        /// <summary>Materialize <paramref name="level"/> and install it as the active puzzle.</summary>
        public void LoadLevel(LevelData level)
        {
            if (level == null) throw new ArgumentNullException(nameof(level));

            var puzzle = level.ToPuzzle();
            _currentLevel = level;
            _size = level.size;
            _difficulty = level.difficulty;
            _mode = level.mode;
            _currentSeed = level.seed;

            _grid.Build(puzzle, _ui, _palette);

            Moves = 0;
            HintsRemaining = maxHintsPerLevel;
            IsWon = false;
            MovesChanged?.Invoke(Moves);
            HintsChanged?.Invoke(HintsRemaining);
            HideTooltip();
            HideWinOverlay();
            RefreshStatsUI();
            RefreshHintBadge();
        }

        private void OnCellToggled(int row, int col)
        {
            if (IsWon) return;
            Moves++;
            MovesChanged?.Invoke(Moves);
            RefreshStatsUI();

            // Player took an action - dismiss any lingering hint tooltip.
            HideTooltip();
        }

        private void OnSolved()
        {
            if (IsWon) return;
            IsWon = true;
            AudioService.PlayWin();
            HapticService.Heavy();
            ShowWinOverlay();
        }

        private void OnResetPressed()
        {
            if (IsWon) return;
            _grid.ResetToLocked();
            Moves = 0;
            MovesChanged?.Invoke(Moves);
            RefreshStatsUI();
        }

        private void OnConfirmPressed()
        {
            if (IsWon || _grid.Puzzle == null) return;

            if (_grid.Puzzle.IsSolved())
            {
                // GridManager will also have raised Solved via the last toggle,
                // but we cover the case where the player holds a solved board and
                // then presses Confirm without a final toggle.
                if (!IsWon) OnSolved();
                return;
            }

            AudioService.PlayWrong();
            HapticService.Medium();

            FlashMismatchedLabels();
            if (_shakeRoutine != null) StopCoroutine(_shakeRoutine);
            _shakeRoutine = StartCoroutine(UITween.Shake(_ui.GridArea, amplitudePx: 14f, durationSeconds: 0.35f));
        }

        private void OnHintPressed()
        {
            if (IsWon || _grid.Puzzle == null) return;

            if (HintsRemaining <= 0)
            {
                ShowTooltip("No hints left on this level. Trust the math.");
                return;
            }

            var hint = HintEngine.GetNext(_grid.Puzzle);
            if (!hint.IsValid)
            {
                ShowTooltip("Looks good - press Confirm.");
                return;
            }

            HintsRemaining--;
            HintsChanged?.Invoke(HintsRemaining);
            RefreshHintBadge();

            AudioService.PlayHint();
            HapticService.Light();

            ShowTooltip(hint.Reason);
            _grid.GetCell(hint.Row, hint.Col)?.Highlight();
        }

        private void OnNextLevelPressed()
        {
            Level++;
            LevelChanged?.Invoke(Level);
            HideWinOverlay();

            if (_currentLevel != null)
            {
                var next = LevelCatalog.Next(_currentLevel);
                if (next != null) { LoadLevel(next); return; }
            }
            LoadNextPuzzle();
        }

        // =====================================================================
        // LEVEL PICKER
        // =====================================================================

        private void OpenLevelPicker()
        {
            if (_ui.LevelPickerOverlay == null) return;
            PopulateLevelPickerList();
            _ui.LevelPickerOverlay.gameObject.SetActive(true);
        }

        private void CloseLevelPicker()
        {
            if (_ui.LevelPickerOverlay == null) return;
            _ui.LevelPickerOverlay.gameObject.SetActive(false);
        }

        private void HideLevelPicker() => CloseLevelPicker();

        private void PopulateLevelPickerList()
        {
            var list = _ui.LevelPickerList;
            if (list == null) return;

            for (int k = list.childCount - 1; k >= 0; k--)
                Destroy(list.GetChild(k).gameObject);

            // A random generator entry always leads the list so the player can skip
            // the catalog entirely. Show the difficulty the auto-ramp would pick for
            // the current Level counter.
            var nextDifficulty = DifficultyForLevel(Level);
            var nextCfg = PuzzleGenerator.PositionalBinaryDifficultyConfig[(int)nextDifficulty];
            var nextSize = _mode == WeightingMode.PositionalBinary ? nextCfg.size : _size;
            var randomBtn = UIBuilder.BuildLevelPickerItem(
                list, _palette,
                displayName: "Random",
                difficultyLabel: nextDifficulty.ToString().ToUpperInvariant(),
                sizeLabel: $"{nextSize}x{nextSize}",
                difficultyColor: ColorForDifficulty(nextDifficulty));
            randomBtn.onClick.AddListener(() =>
            {
                CloseLevelPicker();
                LoadNextPuzzle();
            });

            foreach (var level in LevelCatalog.All)
            {
                var captured = level;
                var btn = UIBuilder.BuildLevelPickerItem(
                    list, _palette,
                    displayName: level.displayName,
                    difficultyLabel: level.difficulty.ToString().ToUpperInvariant(),
                    sizeLabel: $"{level.size}x{level.size}",
                    difficultyColor: ColorForDifficulty(level.difficulty));
                btn.onClick.AddListener(() =>
                {
                    CloseLevelPicker();
                    LoadLevel(captured);
                });
            }
        }

        /// <summary>
        /// Auto-ramp: levels 1-2 play at the baseline the player chose; from level 3
        /// they step up to Medium; from level 6 they step up to Hard. The ramp never
        /// drops BELOW the configured baseline, so a player who boots directly into
        /// Hard always stays on Hard.
        /// </summary>
        private PuzzleDifficulty DifficultyForLevel(int level)
        {
            PuzzleDifficulty ramped;
            if (level <= 2) ramped = PuzzleDifficulty.Easy;
            else if (level <= 5) ramped = PuzzleDifficulty.Medium;
            else ramped = PuzzleDifficulty.Hard;

            return (PuzzleDifficulty)Math.Max((int)ramped, (int)_baselineDifficulty);
        }

        private Color ColorForDifficulty(PuzzleDifficulty difficulty)
        {
            switch (difficulty)
            {
                case PuzzleDifficulty.Easy:   return _palette.targetSatisfied;
                case PuzzleDifficulty.Medium: return _palette.accent;
                case PuzzleDifficulty.Hard:   return _palette.buttonDanger;
                default: return _palette.accent;
            }
        }

        private void FlashMismatchedLabels()
        {
            var puzzle = _grid.Puzzle;
            // Flash every mismatched label - including hidden-target ones, which
            // still show a red "?" flash. This tells the player WHICH axis is
            // wrong without leaking the actual target number.
            for (int i = 0; i < puzzle.Size; i++)
            {
                if (puzzle.RowSums[i] != puzzle.RowTargets[i])
                    _grid.GetRowLabel(i)?.FlashIncorrect();
            }
            for (int j = 0; j < puzzle.Size; j++)
            {
                if (puzzle.ColSums[j] != puzzle.ColTargets[j])
                    _grid.GetColLabel(j)?.FlashIncorrect();
            }
        }

        private void ShowWinOverlay()
        {
            if (_ui.WinOverlay == null) return;
            if (_ui.WinStatsText != null)
            {
                _ui.WinStatsText.text = $"Level {Level} - {Moves} {(Moves == 1 ? "move" : "moves")}";
            }
            _ui.WinOverlay.gameObject.SetActive(true);

            if (_ui.WinCard != null)
            {
                StartCoroutine(UITween.ScaleIn(_ui.WinCard,
                    startScale: 0.55f, overshootScale: 1.08f, durationSeconds: 0.45f));
            }
        }

        private void HideWinOverlay()
        {
            if (_ui.WinOverlay == null) return;
            _ui.WinOverlay.gameObject.SetActive(false);
        }

        private void RefreshStatsUI()
        {
            if (_ui.LevelText != null)
            {
                _ui.LevelText.text = _currentLevel != null
                    ? _currentLevel.displayName.ToUpperInvariant()
                    : $"LEVEL {Level}";
            }
            if (_ui.MovesText != null) _ui.MovesText.text = $"MOVES {Moves}";
        }

        private void RefreshHintBadge()
        {
            if (_ui.HintBadgeText != null) _ui.HintBadgeText.text = HintsRemaining.ToString();
        }

        private void ShowTooltip(string text)
        {
            if (_ui.HintTooltip == null) return;
            if (_ui.HintTooltipText != null) _ui.HintTooltipText.text = text;
            _ui.HintTooltip.gameObject.SetActive(true);

            if (_tooltipRoutine != null) StopCoroutine(_tooltipRoutine);
            _tooltipRoutine = StartCoroutine(HideTooltipAfter(hintTooltipSeconds));
        }

        private void HideTooltip()
        {
            if (_ui.HintTooltip == null) return;
            if (_tooltipRoutine != null) { StopCoroutine(_tooltipRoutine); _tooltipRoutine = null; }
            _ui.HintTooltip.gameObject.SetActive(false);
        }

        private IEnumerator HideTooltipAfter(float seconds)
        {
            yield return new WaitForSecondsRealtime(seconds);
            if (_ui.HintTooltip != null) _ui.HintTooltip.gameObject.SetActive(false);
            _tooltipRoutine = null;
        }

        private void OnDestroy()
        {
            if (_grid != null)
            {
                _grid.CellToggled -= OnCellToggled;
                _grid.Solved -= OnSolved;
            }
            if (_ui != null)
            {
                if (_ui.ResetButton != null) _ui.ResetButton.onClick.RemoveListener(OnResetPressed);
                if (_ui.ConfirmButton != null) _ui.ConfirmButton.onClick.RemoveListener(OnConfirmPressed);
                if (_ui.HintButton != null) _ui.HintButton.onClick.RemoveListener(OnHintPressed);
                if (_ui.WinNextButton != null) _ui.WinNextButton.onClick.RemoveListener(OnNextLevelPressed);
                if (_ui.LevelsButton != null) _ui.LevelsButton.onClick.RemoveListener(OpenLevelPicker);
                if (_ui.LevelPickerCloseButton != null) _ui.LevelPickerCloseButton.onClick.RemoveListener(CloseLevelPicker);
            }
        }
    }
}
