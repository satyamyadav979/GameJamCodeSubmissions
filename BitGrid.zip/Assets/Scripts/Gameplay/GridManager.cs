using System;
using BitGrid.Core;
using BitGrid.Services;
using BitGrid.UI;
using UnityEngine;
using UnityEngine.UI;

namespace BitGrid.Gameplay
{
    /// <summary>
    /// Owns the visible grid and its label strips for a single <see cref="Puzzle"/>.
    /// Responsible for:
    ///   - building CellController + TargetLabelView instances inside the pre-allocated
    ///     UI containers created by <see cref="UIBuilder"/>,
    ///   - routing cell clicks through <see cref="Puzzle.Toggle"/> and keeping the
    ///     affected row/column labels in sync in O(1) per click,
    ///   - emitting <see cref="CellToggled"/> and <see cref="Solved"/> for the
    ///     GameManager (Phase 5+) to react to.
    /// </summary>
    public sealed class GridManager : MonoBehaviour
    {
        public Puzzle Puzzle { get; private set; }
        public bool IsBuilt { get; private set; }

        public event Action<int, int> CellToggled;
        public event Action Solved;

        /// <summary>Lookup the label view for a given row index; null if not built.</summary>
        public TargetLabelView GetRowLabel(int row)
            => (_rowLabels != null && row >= 0 && row < _rowLabels.Length) ? _rowLabels[row] : null;

        /// <summary>Lookup the label view for a given column index; null if not built.</summary>
        public TargetLabelView GetColLabel(int col)
            => (_colLabels != null && col >= 0 && col < _colLabels.Length) ? _colLabels[col] : null;

        /// <summary>Lookup a cell controller; null if indices are out of range.</summary>
        public CellController GetCell(int row, int col)
        {
            if (_cells == null) return null;
            if (row < 0 || col < 0 || row >= _cells.GetLength(0) || col >= _cells.GetLength(1)) return null;
            return _cells[row, col];
        }

        private UIRefs _ui;
        private ThemePalette _palette;
        private CellController[,] _cells;
        private TargetLabelView[] _rowLabels;
        private TargetLabelView[] _colLabels;

        /// <summary>
        /// Rebuild the grid from scratch for the given puzzle. Any existing
        /// cells and labels are destroyed before new ones are created.
        /// </summary>
        public void Build(Puzzle puzzle, UIRefs ui, ThemePalette palette)
        {
            if (puzzle == null) throw new ArgumentNullException(nameof(puzzle));
            if (ui == null) throw new ArgumentNullException(nameof(ui));
            if (palette == null) throw new ArgumentNullException(nameof(palette));

            Puzzle = puzzle;
            _ui = ui;
            _palette = palette;

            ClearChildren(ui.GridCellsContainer);
            ClearChildren(ui.ColumnTargetsContainer);
            ClearChildren(ui.RowTargetsContainer);

            ConfigureGridLayout(puzzle.Size);

            bool showWeights = puzzle.Mode == WeightingMode.PositionalBinary;

            _cells = new CellController[puzzle.Size, puzzle.Size];
            for (int i = 0; i < puzzle.Size; i++)
            {
                for (int j = 0; j < puzzle.Size; j++)
                {
                    var cell = CellController.Create(
                        ui.GridCellsContainer, i, j, palette,
                        rowWeight: puzzle.RowWeight(i, j),
                        colWeight: puzzle.ColWeight(i, j),
                        showWeights: showWeights);
                    cell.SetState(puzzle.Current[i, j], puzzle.Locked[i, j], animate: false);
                    cell.Clicked += OnCellClicked;
                    _cells[i, j] = cell;
                }
            }

            _colLabels = new TargetLabelView[puzzle.Size];
            for (int j = 0; j < puzzle.Size; j++)
            {
                var label = TargetLabelView.Create(
                    ui.ColumnTargetsContainer, puzzle.ColTargets[j], palette,
                    targetVisible: puzzle.ColTargetVisible[j]);
                label.SetCurrent(puzzle.ColSums[j]);
                _colLabels[j] = label;
            }

            _rowLabels = new TargetLabelView[puzzle.Size];
            for (int i = 0; i < puzzle.Size; i++)
            {
                var label = TargetLabelView.Create(
                    ui.RowTargetsContainer, puzzle.RowTargets[i], palette,
                    targetVisible: puzzle.RowTargetVisible[i]);
                label.SetCurrent(puzzle.RowSums[i]);
                _rowLabels[i] = label;
            }

            IsBuilt = true;
        }

        /// <summary>
        /// Reset player state (non-locked cells) and refresh all views.
        /// Cheaper than a full Build because no GameObjects are recreated.
        /// </summary>
        public void ResetToLocked()
        {
            if (!IsBuilt) return;

            Puzzle.ResetToLocked();

            for (int i = 0; i < Puzzle.Size; i++)
            {
                for (int j = 0; j < Puzzle.Size; j++)
                {
                    _cells[i, j].SetState(Puzzle.Current[i, j], Puzzle.Locked[i, j], animate: false);
                }
            }
            for (int i = 0; i < Puzzle.Size; i++) _rowLabels[i].SetCurrent(Puzzle.RowSums[i]);
            for (int j = 0; j < Puzzle.Size; j++) _colLabels[j].SetCurrent(Puzzle.ColSums[j]);
        }

        private void OnCellClicked(CellController cell)
        {
            if (!IsBuilt || cell.IsLocked) return;

            Puzzle.Toggle(cell.Row, cell.Col);
            cell.SetState(Puzzle.Current[cell.Row, cell.Col], locked: false, animate: true);

            // O(1) label refresh: only the affected row and column change.
            _rowLabels[cell.Row].SetCurrent(Puzzle.RowSums[cell.Row]);
            _colLabels[cell.Col].SetCurrent(Puzzle.ColSums[cell.Col]);

            AudioService.PlayClick();
            HapticService.Light();

            CellToggled?.Invoke(cell.Row, cell.Col);

            if (Puzzle.IsSolved()) Solved?.Invoke();
        }

        /// <summary>
        /// Set GridLayoutGroup cell size so the cells fill the container exactly,
        /// accounting for spacing. Called once per Build.
        /// </summary>
        private void ConfigureGridLayout(int size)
        {
            var grid = _ui.GridCellsLayout;
            grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            grid.constraintCount = size;

            // Make sure every ancestor (AspectRatioFitter, anchors, etc.) has
            // resolved its rect before we read width/height for cell sizing.
            Canvas.ForceUpdateCanvases();
            LayoutRebuilder.ForceRebuildLayoutImmediate((RectTransform)_ui.Screen);
            LayoutRebuilder.ForceRebuildLayoutImmediate(_ui.GridArea);
            LayoutRebuilder.ForceRebuildLayoutImmediate(_ui.GridCellsContainer);

            float width = _ui.GridCellsContainer.rect.width;
            float height = _ui.GridCellsContainer.rect.height;
            float spacing = grid.spacing.x;

            float cellW = (width - spacing * (size - 1)) / size;
            float cellH = (height - spacing * (size - 1)) / size;
            float cellSide = Mathf.Max(16f, Mathf.Min(cellW, cellH));

            grid.cellSize = new Vector2(cellSide, cellSide);
        }

        private static void ClearChildren(RectTransform parent)
        {
            for (int k = parent.childCount - 1; k >= 0; k--)
            {
                var child = parent.GetChild(k);
                if (child == null) continue;
                Destroy(child.gameObject);
            }
        }

        private void OnDestroy()
        {
            if (_cells != null)
            {
                foreach (var cell in _cells)
                {
                    if (cell != null) cell.Clicked -= OnCellClicked;
                }
            }
        }
    }
}
