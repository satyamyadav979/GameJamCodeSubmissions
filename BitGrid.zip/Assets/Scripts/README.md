# BitGrid

A 2D grid-logic puzzle for Unity. Each row and column has a target number; the
player toggles cells between 0 and 1 until every row/column sum matches its
target. The default weighting makes each filled cell worth a power of two, so
a row's target is literally the binary number the row encodes.

## Quick start

1. Open the project in Unity 2022.3 LTS (or newer).
2. Open `Assets/Scenes/Game.unity` and press Play.
   - The whole UI is built at runtime by `AppBootstrap` + `UIBuilder`, so the
     scene itself only needs a Camera. No prefab wiring required.
3. Tap cells to toggle, press **Confirm** to check your solution, **Reset** to
   wipe non-locked cells, **Hint** (yellow) to spend a hint credit for a
   teaching nudge, or the **≡** button in the top-left to pick a specific
   level from the catalog.

## Weighting model (PositionalBinary, the default)

- A filled cell `(i, j)` contributes `2^j` to its **row sum** and `2^i` to its
  **column sum**.
- Row target `i` = `Σ_j cells[i,j] * 2^j`  → row reads left-to-right as a
  binary number with column index `j` as the bit position.
- Column target `j` = `Σ_i cells[i,j] * 2^i` → column reads top-to-bottom with
  row index `i` as the bit position.
- Translucent `2^j` / `2^i` labels inside each cell show the per-cell weights.

Every PositionalBinary puzzle is uniquely solvable by construction.

## Difficulty

Difficulty scales both grid size and how many row/column targets are hidden.
Early levels stay fully transparent so the player learns the mechanic; hiding
only kicks in at Hard:

| Difficulty | Grid | Hidden rows | Hidden cols | Locked "given" cells |
| ---------- | ---- | ----------- | ----------- | -------------------- |
| Easy       | 4×4  | 0           | 0           | 0                    |
| Medium     | 5×5  | 0           | 0           | 0                    |
| Hard       | 6×6  | 2           | 2           | 4 (intersections)    |

In Easy and Medium every target is visible, so the puzzle is "just" a binary
decode per row (and a sanity check per column). Hard hides two full rows and
two full columns; those targets render as `?`. Uniqueness is preserved by
locking every cell at the intersection of a hidden row and a hidden column to
its solution value — those are the only cells not directly constrained by
some visible target.

To play a Hard puzzle you decode visible rows from their targets, then use
visible column targets to back-solve the hidden rows' cells by subtracting
the known rows' contributions. The locked givens fill the remaining
hidden-row × hidden-col intersections.

### Auto-ramp during random play

When the player is running random puzzles (not catalog levels), the game
steps the difficulty up as the level counter increases, and never drops below
the baseline the player configured on `AppBootstrap.startingDifficulty`:

| Level counter | Difficulty played         |
| ------------- | ------------------------- |
| 1–2           | `max(baseline, Easy)`     |
| 3–5           | `max(baseline, Medium)`   |
| 6+            | `max(baseline, Hard)`     |

### UnitCount mode

`WeightingMode.UnitCount` treats every filled cell as `+1` (classic "count
the 1s" puzzle). The generator produces it with a difficulty-scaled locked
reveal window (~70% locked for Easy, ~0% for Hard).

## Sample levels (LevelData)

Nine curated levels live in `Assets/Resources/Levels/` (3 Easy, 3 Medium,
3 Hard). Each is a `LevelData` ScriptableObject that freezes the full
solution + lock mask + target-visibility masks as plain 0/1 strings, so it
survives future generator tweaks.

To populate or refresh them, run once from the top menu:

```
BitGrid > Regenerate Sample Levels
```

The fixed seeds used (so re-running is deterministic):

| File          | Difficulty | Seed |
| ------------- | ---------- | ---- |
| `Easy_1`      | Easy       | 101  |
| `Easy_2`      | Easy       | 202  |
| `Easy_3`      | Easy       | 303  |
| `Medium_1`    | Medium     | 404  |
| `Medium_2`    | Medium     | 505  |
| `Medium_3`    | Medium     | 606  |
| `Hard_1`      | Hard       | 707  |
| `Hard_2`      | Hard       | 808  |
| `Hard_3`      | Hard       | 909  |

To boot a specific level, drag it onto `AppBootstrap.startingLevel` in the
Inspector. Otherwise the game generates a fresh puzzle each run using the
`startingSize` / `startingDifficulty` / `weightingMode` / `startingSeed`
fields.

## Accessibility

- High-contrast palette at `ThemePalette.HighContrast` (dark background +
  saturated yellow). Toggle at runtime with the **A** button in the top-right
  corner, or set `AppBootstrap.useHighContrast = true` to start in it.
- Color-independent cues:
  - Locked cells always carry a small pin in the upper-right.
  - Targets show both the running sum and the target number.
  - Hidden targets render as `?` rather than relying on color alone.

## Audio & haptics

`BitGrid.Services.AudioService` synthesizes sine-wave beeps at runtime so no
audio assets ship with the game. Toggle with `AudioService.Muted = true`.

`BitGrid.Services.HapticService` wraps `Handheld.Vibrate` with intent-named
helpers (`Light` / `Medium` / `Heavy`). It's a no-op on desktop and in the
editor.

## Architecture

```
BitGrid.Bootstrap     AppBootstrap (entry point, palette swap)
BitGrid.Core          Puzzle, CellState, WeightingMode, PuzzleDifficulty
BitGrid.Generation    PuzzleGenerator, Solver
BitGrid.Gameplay      GridManager, CellController, GameManager, HintEngine
BitGrid.UI            UIBuilder, UIRefs, TargetLabelView, ThemePalette
BitGrid.Data          LevelData, LevelCatalog
BitGrid.Services      AudioService, HapticService
BitGrid.Utils         UITween, SpriteFactory
BitGrid.EditorTools   LevelAuthoring  (Editor-only asmdef)
```

Key patterns:

- **Runtime UI**. `UIBuilder.Build` constructs every Canvas node at startup
  so there are no brittle scene references; `UIRefs` is the single bag of
  strongly-typed handles every other system reads from.
- **O(1) toggle**. `Puzzle.Toggle` keeps `RowSums` / `ColSums` in sync
  incrementally; `GridManager` only repaints the affected row/col labels per
  click.
- **Uniqueness-preserving generation**. `PuzzleGenerator` picks a random
  solution, hides the difficulty's row/col targets, and locks the hidden
  intersections. The `Solver` can re-verify uniqueness for any board.
- **Event-driven win flow**. `GridManager` raises `CellToggled` / `Solved`;
  `GameManager` listens and drives moves, win overlay, and hints.

## Tests

Edit-mode tests live under `Assets/Tests/EditMode/`:

- `PuzzleTests` — `Toggle`, target/sum arithmetic for both weighting modes.
- `SolverTests` — uniqueness detection.
- `PuzzleGeneratorTests` — difficulty-window enforcement (UnitCount),
  PositionalBinary size / hidden-target counts / lock placement.

Run from Window → General → Test Runner → EditMode → Run All.
