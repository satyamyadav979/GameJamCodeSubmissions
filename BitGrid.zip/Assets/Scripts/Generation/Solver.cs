using System;
using BitGrid.Core;

namespace BitGrid.Generation
{
    /// <summary>
    /// Backtracking solver used by <c>PuzzleGenerator</c> for uniqueness checks and
    /// by <c>HintEngine</c> for deducing forced cells.
    ///
    /// Row-major traversal with two-sided pruning on both rows and columns:
    ///  - Upper-bound prune: partial sum must not exceed the target.
    ///  - Lower-bound prune: partial sum plus the remaining max weight must reach the target.
    ///  - Exact-match when leaving a row/column (last cell) enforces equality.
    /// </summary>
    public static class Solver
    {
        /// <summary>
        /// Count solutions consistent with the given puzzle's targets, honoring locked cells
        /// (locked cells are treated as fixed to their value in <paramref name="puzzle"/>.Current).
        /// Stops counting once the count reaches <paramref name="cap"/>.
        /// </summary>
        /// <returns>Number of solutions found, clamped at <paramref name="cap"/>.</returns>
        public static int CountSolutionsUpTo(Puzzle puzzle, int cap)
        {
            if (puzzle == null) throw new ArgumentNullException(nameof(puzzle));
            if (cap <= 0) return 0;

            int n = puzzle.Size;

            int[] rowRemainingMax = new int[n];
            int[] colRemainingMax = new int[n];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    rowRemainingMax[i] += puzzle.RowWeight(i, j);
                    colRemainingMax[j] += puzzle.ColWeight(i, j);
                }
            }

            int[] rowSum = new int[n];
            int[] colSum = new int[n];

            var ctx = new Context
            {
                Puzzle = puzzle,
                N = n,
                Cap = cap,
                RowTargets = puzzle.RowTargets,
                ColTargets = puzzle.ColTargets,
                RowSum = rowSum,
                ColSum = colSum,
                RowRemaining = rowRemainingMax,
                ColRemaining = colRemainingMax,
                Count = 0,
            };

            Recurse(ref ctx, 0, 0);
            return ctx.Count;
        }

        /// <summary>
        /// Convenience: are there at least two solutions? Used by generators to reject ambiguous puzzles.
        /// </summary>
        public static bool HasUniqueSolution(Puzzle puzzle) => CountSolutionsUpTo(puzzle, 2) == 1;

        private struct Context
        {
            public Puzzle Puzzle;
            public int N;
            public int Cap;
            public int[] RowTargets;
            public int[] ColTargets;
            public int[] RowSum;
            public int[] ColSum;
            public int[] RowRemaining;
            public int[] ColRemaining;
            public int Count;
        }

        private static void Recurse(ref Context ctx, int i, int j)
        {
            if (ctx.Count >= ctx.Cap) return;

            if (i == ctx.N)
            {
                ctx.Count++;
                return;
            }

            int nextI = j + 1 == ctx.N ? i + 1 : i;
            int nextJ = j + 1 == ctx.N ? 0 : j + 1;

            int rw = ctx.Puzzle.RowWeight(i, j);
            int cw = ctx.Puzzle.ColWeight(i, j);
            bool locked = ctx.Puzzle.Locked[i, j];
            int lockedValue = locked ? (int)ctx.Puzzle.Current[i, j] : -1;

            for (int v = 0; v < 2; v++)
            {
                if (locked && v != lockedValue) continue;

                int rowAdd = v * rw;
                int colAdd = v * cw;
                int newRowSum = ctx.RowSum[i] + rowAdd;
                int newColSum = ctx.ColSum[j] + colAdd;
                int newRowRem = ctx.RowRemaining[i] - rw;
                int newColRem = ctx.ColRemaining[j] - cw;

                if (newRowSum > ctx.RowTargets[i]) continue;
                if (newRowSum + newRowRem < ctx.RowTargets[i]) continue;
                if (newColSum > ctx.ColTargets[j]) continue;
                if (newColSum + newColRem < ctx.ColTargets[j]) continue;

                bool lastInRow = j == ctx.N - 1;
                bool lastInCol = i == ctx.N - 1;
                if (lastInRow && newRowSum != ctx.RowTargets[i]) continue;
                if (lastInCol && newColSum != ctx.ColTargets[j]) continue;

                ctx.RowSum[i] = newRowSum;
                ctx.ColSum[j] = newColSum;
                ctx.RowRemaining[i] = newRowRem;
                ctx.ColRemaining[j] = newColRem;

                Recurse(ref ctx, nextI, nextJ);

                ctx.RowSum[i] -= rowAdd;
                ctx.ColSum[j] -= colAdd;
                ctx.RowRemaining[i] += rw;
                ctx.ColRemaining[j] += cw;

                if (ctx.Count >= ctx.Cap) return;
            }
        }
    }
}
