using System;
using System.Collections.Generic;
using BitGrid.Core;

namespace BitGrid.Generation
{
    /// <summary>
    /// Produces <see cref="Puzzle"/> instances that are:
    ///  - structurally non-trivial (not all-zero, not all-one, not identical rows/cols),
    ///  - uniquely solvable given the revealed (locked) cells,
    ///  - not already solved by the reveals alone,
    ///  - within the difficulty's target reveal-density window.
    ///
    /// Strategy: random solution -> greedy "unlock while unique" from a fully-locked start.
    /// Starting fully-locked guarantees uniqueness at step zero; each candidate unlock is
    /// committed only if <see cref="Solver.HasUniqueSolution"/> still holds.
    /// </summary>
    public static class PuzzleGenerator
    {
        /// <summary>Upper bound on random-solution retries before giving up.</summary>
        private const int MaxSolutionAttempts = 200;

        /// <summary>
        /// Per-difficulty reveal-density windows expressed as fractions of total cells:
        ///   target -> where the unlock loop tries to stop,
        ///   lo/hi  -> acceptance window; outside this range we retry with a new solution.
        /// </summary>
        private static readonly (double target, double lo, double hi)[] DifficultyRanges =
        {
            (0.70, 0.55, 0.85), // Easy
            (0.45, 0.30, 0.60), // Medium
            (0.00, 0.00, 0.20), // Hard
        };

        /// <summary>
        /// Per-difficulty configuration for <see cref="WeightingMode.PositionalBinary"/>:
        ///   - <c>size</c>: grid side (bigger grid = more bits to decode, wider target range).
        ///   - <c>hiddenRows</c> / <c>hiddenCols</c>: how many row/column targets are rendered
        ///     as "?" and must be deduced. Uniqueness is preserved by locking the
        ///     hidden-row x hidden-col intersection cells to their solution values
        ///     (those cells are the only free variables when both their row and column
        ///     targets are hidden).
        /// </summary>
        public static readonly (int size, int hiddenRows, int hiddenCols)[] PositionalBinaryDifficultyConfig =
        {
            (4, 0, 0), // Easy:   pure binary-decoding of 4 rows, 0..15 range, nothing hidden
            (5, 0, 0), // Medium: 5x5 scales number range to 0..31; still no hiding
            (6, 2, 2), // Hard:   6x6 with two hidden rows + columns, 4 givens at intersections
        };

        /// <summary>
        /// Generate a fresh <see cref="Puzzle"/>.
        /// </summary>
        /// <param name="size">Grid side length; must be >= 2. For PositionalBinary, size is
        /// overridden by the difficulty config unless the caller passes a value greater than
        /// the config's minimum (advanced callers / sample levels can force larger sizes).</param>
        /// <param name="difficulty">Selects a size / hidden-targets / reveal-density preset.</param>
        /// <param name="mode">Weighting mode used by <see cref="Puzzle.RowWeight"/> and the solver.</param>
        /// <param name="seed">Zero for a non-deterministic seed; any non-zero value is used as-is
        /// to make generation reproducible (useful for sample levels and tests).</param>
        public static Puzzle Generate(
            int size,
            PuzzleDifficulty difficulty,
            WeightingMode mode = WeightingMode.PositionalBinary,
            int seed = 0)
        {
            if (size < 2)
                throw new ArgumentOutOfRangeException(nameof(size), "Minimum puzzle size is 2.");

            var rng = seed == 0 ? new Random() : new Random(seed);

            if (mode == WeightingMode.PositionalBinary)
            {
                var cfg = PositionalBinaryDifficultyConfig[(int)difficulty];
                int effectiveSize = Math.Max(size, cfg.size);
                return GeneratePositionalBinary(effectiveSize, cfg.hiddenRows, cfg.hiddenCols, rng);
            }

            for (int attempt = 0; attempt < MaxSolutionAttempts; attempt++)
            {
                var solution = RandomSolution(size, rng);
                if (IsStructurallyTrivial(solution, size)) continue;
                if (!HasTargetVariety(solution, size)) continue;

                var locked = BuildLockMask(size, solution, mode, difficulty, rng);
                if (locked == null) continue;

                var puzzle = new Puzzle(size, mode, solution, locked);
                if (puzzle.IsSolved()) continue;            // reveals alone solve it
                if (!HasInteractionWorkToDo(puzzle)) continue;
                if (!Solver.HasUniqueSolution(puzzle)) continue;  // safety double-check

                return puzzle;
            }

            throw new InvalidOperationException(
                $"PuzzleGenerator failed to produce a puzzle of size {size} at difficulty " +
                $"{difficulty} in {MaxSolutionAttempts} attempts. Try a different seed or size.");
        }

        /// <summary>
        /// Positional-binary generation with optional hidden row/column targets.
        ///
        /// Algorithm:
        ///  1. Pick a random solution grid; reject structurally trivial / low-variety grids.
        ///  2. Pick <paramref name="hiddenRows"/> distinct row indices and <paramref name="hiddenCols"/>
        ///     distinct column indices uniformly at random.
        ///  3. Lock every cell at (hiddenRow, hiddenCol) to its solution value. These are the
        ///     ONLY cells not determined by a visible row or column target, so locking them
        ///     preserves the puzzle's unique solvability.
        ///  4. Emit the puzzle with the row/col visibility masks applied.
        ///
        /// Why this is hard: visible row targets still trivially decode those rows, but hidden-row
        /// cells in visible columns must be deduced by subtracting the known rows' contributions
        /// and decoding the remainder's bit pattern (columns in PositionalBinary also weight by
        /// powers of 2). Hidden-row x hidden-col cells are given outright as locks to keep the
        /// system uniquely solvable.
        /// </summary>
        private static Puzzle GeneratePositionalBinary(int size, int hiddenRows, int hiddenCols, Random rng)
        {
            if (hiddenRows < 0 || hiddenRows >= size)
                throw new ArgumentOutOfRangeException(nameof(hiddenRows));
            if (hiddenCols < 0 || hiddenCols >= size)
                throw new ArgumentOutOfRangeException(nameof(hiddenCols));

            for (int attempt = 0; attempt < MaxSolutionAttempts; attempt++)
            {
                var solution = RandomSolution(size, rng);

                if (IsStructurallyTrivial(solution, size)) continue;
                if (!HasPositionalBinaryVariety(solution, size)) continue;

                var hiddenRowSet = PickDistinctIndices(size, hiddenRows, rng);
                var hiddenColSet = PickDistinctIndices(size, hiddenCols, rng);

                var locked = new bool[size, size];
                foreach (int r in hiddenRowSet)
                    foreach (int c in hiddenColSet)
                        locked[r, c] = true;

                var rowVisible = BuildVisibilityMask(size, hiddenRowSet);
                var colVisible = BuildVisibilityMask(size, hiddenColSet);

                return new Puzzle(size, WeightingMode.PositionalBinary, solution, locked,
                    rowTargetVisible: rowVisible, colTargetVisible: colVisible);
            }

            throw new InvalidOperationException(
                $"PositionalBinary generation failed for size {size} (hiddenRows={hiddenRows}, " +
                $"hiddenCols={hiddenCols}) after {MaxSolutionAttempts} attempts.");
        }

        private static HashSet<int> PickDistinctIndices(int size, int count, Random rng)
        {
            var result = new HashSet<int>();
            if (count <= 0) return result;

            var pool = new List<int>(size);
            for (int i = 0; i < size; i++) pool.Add(i);
            for (int picked = 0; picked < count && pool.Count > 0; picked++)
            {
                int idx = rng.Next(pool.Count);
                result.Add(pool[idx]);
                pool.RemoveAt(idx);
            }
            return result;
        }

        private static bool[] BuildVisibilityMask(int size, HashSet<int> hiddenSet)
        {
            var mask = new bool[size];
            for (int i = 0; i < size; i++) mask[i] = !hiddenSet.Contains(i);
            return mask;
        }

        /// <summary>
        /// Prefer solutions whose row targets are not all identical and whose columns likewise
        /// vary - avoids boring "every row decodes to the same number" puzzles.
        /// </summary>
        private static bool HasPositionalBinaryVariety(CellState[,] s, int n)
        {
            int firstRowTarget = 0;
            int firstColTarget = 0;
            for (int j = 0; j < n; j++)
                if (s[0, j] == CellState.One) firstRowTarget += 1 << j;
            for (int i = 0; i < n; i++)
                if (s[i, 0] == CellState.One) firstColTarget += 1 << i;

            bool rowVaries = false;
            for (int i = 1; i < n && !rowVaries; i++)
            {
                int t = 0;
                for (int j = 0; j < n; j++)
                    if (s[i, j] == CellState.One) t += 1 << j;
                if (t != firstRowTarget) rowVaries = true;
            }

            bool colVaries = false;
            for (int j = 1; j < n && !colVaries; j++)
            {
                int t = 0;
                for (int i = 0; i < n; i++)
                    if (s[i, j] == CellState.One) t += 1 << i;
                if (t != firstColTarget) colVaries = true;
            }

            return rowVaries && colVaries;
        }

        private static CellState[,] RandomSolution(int size, Random rng)
        {
            var grid = new CellState[size, size];
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    grid[i, j] = (rng.Next() & 1) == 0 ? CellState.Zero : CellState.One;
                }
            }
            return grid;
        }

        /// <summary>
        /// Rejects solution grids that produce boring puzzles regardless of reveal set:
        /// near-empty, near-full, identical-rows, identical-columns.
        /// </summary>
        private static bool IsStructurallyTrivial(CellState[,] s, int n)
        {
            int ones = 0;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    if (s[i, j] == CellState.One) ones++;

            if (ones <= 1 || ones >= n * n - 1) return true;

            bool rowsAllSame = true;
            for (int i = 1; i < n && rowsAllSame; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    if (s[i, j] != s[0, j]) { rowsAllSame = false; break; }
                }
            }
            if (rowsAllSame) return true;

            bool colsAllSame = true;
            for (int j = 1; j < n && colsAllSame; j++)
            {
                for (int i = 0; i < n; i++)
                {
                    if (s[i, j] != s[i, 0]) { colsAllSame = false; break; }
                }
            }
            if (colsAllSame) return true;

            return false;
        }

        /// <summary>
        /// Greedily unlock cells (in shuffled order) starting from a fully-locked board.
        /// An unlock is kept only if the puzzle remains uniquely solvable. Stop when we reach
        /// the difficulty's target lock count, then validate against the acceptance window.
        /// </summary>
        /// <returns>Lock mask on success; null if the final density fell outside the window.</returns>
        private static bool[,] BuildLockMask(
            int size,
            CellState[,] solution,
            WeightingMode mode,
            PuzzleDifficulty difficulty,
            Random rng)
        {
            var range = DifficultyRanges[(int)difficulty];
            int nCells = size * size;
            int stopAtLocks = (int)Math.Round(nCells * range.target);
            int minAllowedLocks = (int)Math.Floor(nCells * range.lo);
            int maxAllowedLocks = (int)Math.Ceiling(nCells * range.hi);

            var locked = new bool[size, size];
            for (int i = 0; i < size; i++)
                for (int j = 0; j < size; j++)
                    locked[i, j] = true;

            var order = BuildShuffledIndices(size, rng);
            int currentLocks = nCells;

            foreach (var cell in order)
            {
                if (currentLocks <= stopAtLocks) break;

                int i = cell.Item1;
                int j = cell.Item2;

                locked[i, j] = false;
                var candidate = new Puzzle(size, mode, solution, locked);
                if (Solver.HasUniqueSolution(candidate))
                {
                    currentLocks--;
                }
                else
                {
                    locked[i, j] = true;
                }
            }

            if (currentLocks < minAllowedLocks || currentLocks > maxAllowedLocks) return null;
            return locked;
        }

        private static List<(int, int)> BuildShuffledIndices(int size, Random rng)
        {
            var list = new List<(int, int)>(size * size);
            for (int i = 0; i < size; i++)
                for (int j = 0; j < size; j++)
                    list.Add((i, j));

            for (int k = list.Count - 1; k > 0; k--)
            {
                int swap = rng.Next(k + 1);
                (list[k], list[swap]) = (list[swap], list[k]);
            }
            return list;
        }

        /// <summary>
        /// Visual-variety filter: rejects solutions whose row/column targets all fall in a
        /// narrow band (e.g. every target is 1 or 2 on a 4x4). Puzzles with at least one
        /// high and one low target feel richer and give the solver more to reason about.
        /// </summary>
        private static bool HasTargetVariety(CellState[,] s, int n)
        {
            int highTarget = (n / 2) + 1;           // 4x4 -> 3, 5x5 -> 3, 6x6 -> 4
            int lowTarget = Math.Max(1, (n / 2) - 1); // 4x4 -> 1, 5x5 -> 1, 6x6 -> 2

            bool seenHigh = false, seenLow = false;

            for (int i = 0; i < n; i++)
            {
                int rowCount = 0;
                for (int j = 0; j < n; j++)
                    if (s[i, j] == CellState.One) rowCount++;
                if (rowCount >= highTarget) seenHigh = true;
                if (rowCount <= lowTarget) seenLow = true;
            }
            for (int j = 0; j < n; j++)
            {
                int colCount = 0;
                for (int i = 0; i < n; i++)
                    if (s[i, j] == CellState.One) colCount++;
                if (colCount >= highTarget) seenHigh = true;
                if (colCount <= lowTarget) seenLow = true;
            }

            return seenHigh && seenLow;
        }

        /// <summary>
        /// Ensures the player has at least one cell to toggle to reach the solution.
        /// Redundant with <see cref="Puzzle.IsSolved"/> given uniqueness, but kept for
        /// clarity and as a guard against future refactors.
        /// </summary>
        private static bool HasInteractionWorkToDo(Puzzle puzzle)
        {
            for (int i = 0; i < puzzle.Size; i++)
            {
                for (int j = 0; j < puzzle.Size; j++)
                {
                    if (!puzzle.Locked[i, j] && puzzle.Solution[i, j] == CellState.One)
                        return true;
                }
            }
            return false;
        }
    }
}
