using UnityEngine;

namespace BitGrid.UI
{
    /// <summary>
    /// Central color palette. Every UI element pulls from here so re-skinning the whole
    /// game is a single-asset change. If no palette asset is assigned on bootstrap,
    /// <see cref="Default"/> provides a pastel-lavender fallback baked in code.
    /// </summary>
    [CreateAssetMenu(
        fileName = "DefaultTheme",
        menuName = "BitGrid/Theme Palette",
        order = 0)]
    public sealed class ThemePalette : ScriptableObject
    {
        [Header("Background")]
        public Color backgroundTop = FromHex("#EEE5F6");
        public Color backgroundBottom = FromHex("#D8CFE8");

        [Header("Cells")]
        public Color cellOff = FromHex("#F6F3FB");          // near-white: clickable empty
        public Color cellOn = FromHex("#7B6CF6");           // bold purple: clickable filled
        public Color cellOffLocked = FromHex("#D8D3E8");    // medium lavender: given empty
        public Color cellOnLocked = FromHex("#5F51D9");     // deep purple: given filled
        public Color cellLockedPin = FromHex("#2E2A4A");    // dark dot overlay on locked cells
        public Color cellCorrectGlow = FromHex("#5DD6A0");
        public Color cellIncorrectGlow = FromHex("#F47B7B");

        [Header("Text")]
        public Color textPrimary = FromHex("#2E2A4A");
        public Color textMuted = FromHex("#6B6A8F");
        public Color textOnAccent = FromHex("#FFFFFF");

        [Header("Accents / Buttons")]
        public Color accent = FromHex("#7B6CF6");
        public Color accentPressed = FromHex("#5F51D9");
        public Color buttonNeutral = FromHex("#FFFFFF");
        public Color buttonDanger = FromHex("#F47B7B");

        [Header("Targets & Status")]
        public Color targetNeutral = FromHex("#FFFFFF");
        public Color targetSatisfied = FromHex("#5DD6A0");
        public Color targetExceeded = FromHex("#F47B7B");

        [Header("Hint")]
        public Color hintGlow = FromHex("#F6E37B");

        /// <summary>Lazy, runtime-built fallback palette. Safe when no asset is assigned.</summary>
        private static ThemePalette s_default;
        private static ThemePalette s_highContrast;

        public static ThemePalette Default
        {
            get
            {
                if (s_default == null)
                {
                    s_default = CreateInstance<ThemePalette>();
                    s_default.name = "DefaultTheme (Runtime)";
                    s_default.hideFlags = HideFlags.HideAndDontSave;
                }
                return s_default;
            }
        }

        /// <summary>
        /// High-contrast palette for accessibility. Dark background with high-lightness
        /// yellow "on" cells and white text. All state transitions remain distinguishable
        /// even in grayscale. Built lazily the first time it is requested.
        /// </summary>
        public static ThemePalette HighContrast
        {
            get
            {
                if (s_highContrast == null)
                {
                    var p = CreateInstance<ThemePalette>();
                    p.name = "HighContrast (Runtime)";
                    p.hideFlags = HideFlags.HideAndDontSave;

                    p.backgroundTop = FromHex("#0B0B10");
                    p.backgroundBottom = FromHex("#15151F");

                    p.cellOff = FromHex("#1E1E2A");
                    p.cellOn = FromHex("#FFD400");
                    p.cellOffLocked = FromHex("#2E2E3E");
                    p.cellOnLocked = FromHex("#FFA500");
                    p.cellLockedPin = FromHex("#FFFFFF");
                    p.cellCorrectGlow = FromHex("#00E676");
                    p.cellIncorrectGlow = FromHex("#FF5252");

                    p.textPrimary = FromHex("#FFFFFF");
                    p.textMuted = FromHex("#B8B8D0");
                    p.textOnAccent = FromHex("#0B0B10");

                    p.accent = FromHex("#FFD400");
                    p.accentPressed = FromHex("#FFA500");
                    p.buttonNeutral = FromHex("#2E2E3E");
                    p.buttonDanger = FromHex("#FF5252");

                    p.targetNeutral = FromHex("#2E2E3E");
                    p.targetSatisfied = FromHex("#00E676");
                    p.targetExceeded = FromHex("#FF5252");

                    p.hintGlow = FromHex("#FFE066");

                    s_highContrast = p;
                }
                return s_highContrast;
            }
        }

        private static Color FromHex(string hex)
        {
            if (ColorUtility.TryParseHtmlString(hex, out var c)) return c;
            return Color.magenta;
        }
    }
}
