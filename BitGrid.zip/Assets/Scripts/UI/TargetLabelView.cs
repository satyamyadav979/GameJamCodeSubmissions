using BitGrid.Utils;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BitGrid.UI
{
    /// <summary>
    /// Row or column target label. Shows the target number prominently and the
    /// live running sum underneath; background color reflects whether the current
    /// sum is below, equal to, or above the target.
    /// </summary>
    [RequireComponent(typeof(RectTransform), typeof(Image))]
    public sealed class TargetLabelView : MonoBehaviour
    {
        public int Target { get; private set; }
        public int Current { get; private set; }

        /// <summary>
        /// When false, the target number is rendered as "?" and the running sum is
        /// still shown. Background color stays neutral until the puzzle is solved
        /// (we can't meaningfully color "satisfied" without a known target).
        /// </summary>
        public bool TargetVisible { get; private set; } = true;

        private Image _background;
        private TextMeshProUGUI _targetText;
        private TextMeshProUGUI _currentText;
        private ThemePalette _palette;
        private RectTransform _rt;
        private bool _wasSatisfied;
        private Coroutine _popRoutine;

        public static TargetLabelView Create(RectTransform parent, int target, ThemePalette palette, bool targetVisible = true)
        {
            var go = new GameObject("TargetLabel",
                typeof(RectTransform), typeof(Image), typeof(TargetLabelView));
            go.transform.SetParent(parent, worldPositionStays: false);

            var view = go.GetComponent<TargetLabelView>();
            view.Initialize(target, palette, targetVisible);
            return view;
        }

        private void Initialize(int target, ThemePalette palette, bool targetVisible)
        {
            _palette = palette;
            Target = target;
            Current = 0;
            TargetVisible = targetVisible;

            _rt = (RectTransform)transform;

            _background = GetComponent<Image>();
            _background.sprite = SpriteFactory.RoundedRect();
            _background.type = Image.Type.Sliced;
            _background.color = palette.targetNeutral;
            _background.raycastTarget = false;

            _targetText = CreateText("Target", fontSize: 48, color: palette.textPrimary,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Bold);
            var targetRt = (RectTransform)_targetText.transform;
            targetRt.anchorMin = new Vector2(0f, 0.35f);
            targetRt.anchorMax = new Vector2(1f, 1f);
            targetRt.offsetMin = new Vector2(4f, 0f);
            targetRt.offsetMax = new Vector2(-4f, -4f);

            _currentText = CreateText("Current", fontSize: 24, color: palette.textMuted,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Normal);
            var currentRt = (RectTransform)_currentText.transform;
            currentRt.anchorMin = new Vector2(0f, 0f);
            currentRt.anchorMax = new Vector2(1f, 0.35f);
            currentRt.offsetMin = new Vector2(4f, 4f);
            currentRt.offsetMax = new Vector2(-4f, 0f);

            RefreshLabels();
        }

        /// <summary>Update the displayed running sum and recolor the background.</summary>
        public void SetCurrent(int current)
        {
            bool wasSatisfied = _wasSatisfied;
            Current = current;
            RefreshLabels();

            bool isSatisfied = Current == Target;
            // Only announce satisfaction when the target is visible - otherwise
            // the pop would leak information about hidden targets.
            if (TargetVisible && isSatisfied && !wasSatisfied)
            {
                if (_popRoutine != null) StopCoroutine(_popRoutine);
                _popRoutine = StartCoroutine(UITween.Pop(transform, peakScale: 1.18f, durationSeconds: 0.22f));
            }
            _wasSatisfied = isSatisfied;
        }

        /// <summary>Flash the background briefly red and shake (called on Confirm mismatch).</summary>
        public void FlashIncorrect()
        {
            StopAllCoroutines();
            StartCoroutine(FlashIncorrectRoutine());
        }

        private System.Collections.IEnumerator FlashIncorrectRoutine()
        {
            // Pulse red for visibility regardless of current/target relation.
            _background.color = _palette.targetExceeded;
            _targetText.color = _palette.textOnAccent;
            _currentText.color = _palette.textOnAccent;

            yield return UITween.Shake(_rt, amplitudePx: 8f, durationSeconds: 0.35f);

            RefreshLabels();
        }

        private void RefreshLabels()
        {
            if (!TargetVisible)
            {
                // Player does not know the target yet; they see only what they've placed.
                _targetText.text = "?";
                _currentText.text = Current.ToString();
                _background.color = _palette.targetNeutral;
                _targetText.color = _palette.textPrimary;
                _currentText.color = _palette.textMuted;
                return;
            }

            _targetText.text = Target.ToString();

            if (Current == Target)
            {
                _currentText.text = $"{Current}/{Target}";
                _background.color = _palette.targetSatisfied;
                _targetText.color = _palette.textOnAccent;
                _currentText.color = _palette.textOnAccent;
            }
            else if (Current > Target)
            {
                _currentText.text = $"{Current}/{Target}";
                _background.color = _palette.targetExceeded;
                _targetText.color = _palette.textOnAccent;
                _currentText.color = _palette.textOnAccent;
            }
            else
            {
                _currentText.text = $"{Current}/{Target}";
                _background.color = _palette.targetNeutral;
                _targetText.color = _palette.textPrimary;
                _currentText.color = _palette.textMuted;
            }
        }

        private TextMeshProUGUI CreateText(
            string name, float fontSize, Color color,
            TextAlignmentOptions alignment, FontStyles style)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(transform, worldPositionStays: false);

            var rt = (RectTransform)go.transform;
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;

            var tmp = go.AddComponent<TextMeshProUGUI>();
            tmp.text = string.Empty;
            tmp.fontSize = fontSize;
            tmp.color = color;
            tmp.alignment = alignment;
            tmp.fontStyle = style;
            tmp.raycastTarget = false;
            tmp.enableAutoSizing = true;
            tmp.fontSizeMin = 12f;
            tmp.fontSizeMax = fontSize;
            return tmp;
        }
    }
}
