using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BitGrid.UI
{
    /// <summary>
    /// Strongly-typed pointer bag into the runtime-built UI hierarchy. Attached
    /// to the [UIRoot] GameObject during <see cref="UIBuilder.Build"/>. Later
    /// systems (GridManager, GameManager, HintEngine) read from this instead of
    /// calling FindObjectOfType on hot paths.
    /// </summary>
    public sealed class UIRefs : MonoBehaviour
    {
        [Header("Root")]
        public Canvas Canvas;
        public RectTransform Screen;
        public Image BackgroundGradient;
        public ThemePalette Palette;

        [Header("Top Bar")]
        public RectTransform TopBar;
        public TextMeshProUGUI TitleText;
        public TextMeshProUGUI LevelText;
        public TextMeshProUGUI MovesText;

        [Header("Grid Area")]
        public RectTransform GridArea;
        public RectTransform ColumnTargetsContainer;
        public RectTransform RowTargetsContainer;
        public RectTransform GridCellsContainer;
        public HorizontalLayoutGroup ColumnTargetsLayout;
        public VerticalLayoutGroup RowTargetsLayout;
        public GridLayoutGroup GridCellsLayout;

        [Header("Bottom Bar")]
        public RectTransform BottomBar;
        public Button ResetButton;
        public Button HintButton;
        public Button ConfirmButton;
        public TextMeshProUGUI HintBadgeText;

        [Header("Overlays (hidden by default)")]
        public RectTransform HintTooltip;
        public TextMeshProUGUI HintTooltipText;
        public RectTransform WinOverlay;
        public RectTransform WinCard;
        public TextMeshProUGUI WinStatsText;
        public Button WinNextButton;

        [Header("Accessibility")]
        public Button AccessibilityButton;
        public TextMeshProUGUI AccessibilityButtonLabel;

        [Header("Level Picker")]
        public Button LevelsButton;
        public RectTransform LevelPickerOverlay;
        public RectTransform LevelPickerList;
        public Button LevelPickerCloseButton;
    }
}
