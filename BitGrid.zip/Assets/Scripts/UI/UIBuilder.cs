using BitGrid.Utils;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace BitGrid.UI
{
    /// <summary>
    /// Constructs the entire BitGrid Canvas hierarchy at runtime. The scene itself
    /// only needs a camera; everything else is produced here. Call <see cref="Build"/>
    /// once during bootstrap and keep the returned <see cref="UIRefs"/> for later phases.
    ///
    /// Reference resolution is 1080x1920 (portrait phone). All sizes below are in
    /// reference pixels; CanvasScaler handles per-device scaling.
    /// </summary>
    public static class UIBuilder
    {
        // ----- Layout constants (reference pixels at 1080x1920) -----
        public const float ReferenceWidth = 1080f;
        public const float ReferenceHeight = 1920f;

        private const float TopBarHeight = 260f;
        private const float BottomBarHeight = 220f;
        private const float SideMargin = 40f;
        /// <summary>
        /// Extra breathing room above the top-bar's interactive content (title,
        /// corner buttons). Keeps everything clear of browser chrome / notches on
        /// host environments where the visible viewport is slightly shorter than
        /// the reference 1920.
        /// </summary>
        private const float SafeAreaTop = 40f;
        private const float TargetStripThickness = 110f;
        private const float CornerSpacerSize = 110f;
        private const float BottomButtonHeight = 140f;
        private const float BottomButtonSpacing = 30f;

        /// <summary>
        /// Build the full UI. Returns a populated <see cref="UIRefs"/> attached to
        /// [UIRoot]. Also creates an [EventSystem] root if one doesn't already exist.
        /// </summary>
        public static UIRefs Build(ThemePalette palette)
        {
            if (palette == null) palette = ThemePalette.Default;

            EnsureEventSystem();

            var rootGo = new GameObject("[UIRoot]", typeof(RectTransform));
            var refs = rootGo.AddComponent<UIRefs>();
            refs.Palette = palette;

            BuildCanvas(rootGo, refs);
            BuildBackground(refs);
            BuildTopBar(refs);
            BuildGridArea(refs);
            BuildBottomBar(refs);
            BuildHintTooltip(refs);
            BuildWinOverlay(refs);
            BuildLevelPickerOverlay(refs);

            return refs;
        }

        // ========================================================================
        // CANVAS ROOT
        // ========================================================================

        private static void BuildCanvas(GameObject rootGo, UIRefs refs)
        {
            var canvasGo = new GameObject("Canvas",
                typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            canvasGo.transform.SetParent(rootGo.transform, worldPositionStays: false);

            var canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 0;

            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(ReferenceWidth, ReferenceHeight);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            // 1.0 = match HEIGHT. The layout is portrait-first and vertically dense
            // (top bar + grid + bottom bar), so we lock the vertical reference at
            // 1920 and let horizontal width flex. This prevents the top bar from
            // being clipped when the host iframe's aspect ratio doesn't match
            // exactly 9:16 (common on itch.io embeds and desktop browser windows).
            scaler.matchWidthOrHeight = 1f;
            scaler.referencePixelsPerUnit = 100f;

            refs.Canvas = canvas;
            refs.Screen = (RectTransform)canvasGo.transform;
        }

        // ========================================================================
        // BACKGROUND
        // ========================================================================

        private static void BuildBackground(UIRefs refs)
        {
            var bgGo = new GameObject("BackgroundGradient", typeof(RectTransform), typeof(Image));
            bgGo.transform.SetParent(refs.Screen, worldPositionStays: false);

            var rt = (RectTransform)bgGo.transform;
            StretchFull(rt);

            var img = bgGo.GetComponent<Image>();
            img.sprite = null;
            img.color = refs.Palette.backgroundTop;
            img.raycastTarget = false;

            refs.BackgroundGradient = img;
        }

        // ========================================================================
        // TOP BAR
        // ========================================================================

        private static void BuildTopBar(UIRefs refs)
        {
            var bar = new GameObject("TopBar", typeof(RectTransform));
            bar.transform.SetParent(refs.Screen, worldPositionStays: false);

            var rt = (RectTransform)bar.transform;
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(0.5f, 1f);
            rt.anchoredPosition = new Vector2(0f, 0f);
            rt.sizeDelta = new Vector2(0f, TopBarHeight);
            refs.TopBar = rt;

            // Title, top-centered
            refs.TitleText = CreateText(rt, "TitleText", "BitGrid",
                fontSize: 92, color: refs.Palette.textPrimary,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Bold);
            var titleRt = (RectTransform)refs.TitleText.transform;
            titleRt.anchorMin = new Vector2(0f, 1f);
            titleRt.anchorMax = new Vector2(1f, 1f);
            titleRt.pivot = new Vector2(0.5f, 1f);
            titleRt.anchoredPosition = new Vector2(0f, -(SafeAreaTop + 30f));
            titleRt.sizeDelta = new Vector2(-80f, 110f);

            // Stats row: Level (left) | Moves (right)
            refs.LevelText = CreateStatsText(rt, "LevelText", "LEVEL 1", alignX: 0f, refs);
            refs.MovesText = CreateStatsText(rt, "MovesText", "MOVES 0", alignX: 1f, refs);

            BuildAccessibilityButton(rt, refs);
            BuildLevelsButton(rt, refs);
        }

        private static void BuildLevelsButton(RectTransform parent, UIRefs refs)
        {
            var go = new GameObject("LevelsButton",
                typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, worldPositionStays: false);

            var rt = (RectTransform)go.transform;
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.sizeDelta = new Vector2(84f, 84f);
            rt.anchoredPosition = new Vector2(24f, -(SafeAreaTop + 24f));

            var img = go.GetComponent<Image>();
            img.sprite = SpriteFactory.Circle();
            img.color = refs.Palette.buttonNeutral;

            var btn = go.GetComponent<Button>();
            var colors = btn.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 1f, 1f, 0.9f);
            colors.pressedColor = new Color(0.85f, 0.85f, 0.85f, 1f);
            colors.selectedColor = Color.white;
            colors.disabledColor = new Color(1f, 1f, 1f, 0.4f);
            btn.colors = colors;

            var label = CreateText(rt, "Label", "\u2261", // U+2261 IDENTICAL TO (three bars)
                fontSize: 54, color: refs.Palette.textPrimary,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Bold);
            var lrt = (RectTransform)label.transform;
            StretchFull(lrt);

            refs.LevelsButton = btn;
        }

        private static void BuildAccessibilityButton(RectTransform parent, UIRefs refs)
        {
            var go = new GameObject("AccessibilityButton",
                typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, worldPositionStays: false);

            var rt = (RectTransform)go.transform;
            rt.anchorMin = new Vector2(1f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(1f, 1f);
            rt.sizeDelta = new Vector2(84f, 84f);
            rt.anchoredPosition = new Vector2(-24f, -(SafeAreaTop + 24f));

            var img = go.GetComponent<Image>();
            img.sprite = SpriteFactory.Circle();
            img.color = refs.Palette.buttonNeutral;

            var btn = go.GetComponent<Button>();
            var colors = btn.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 1f, 1f, 0.9f);
            colors.pressedColor = new Color(0.85f, 0.85f, 0.85f, 1f);
            colors.selectedColor = Color.white;
            colors.disabledColor = new Color(1f, 1f, 1f, 0.4f);
            btn.colors = colors;

            var label = CreateText(rt, "Label", "A",
                fontSize: 40, color: refs.Palette.textPrimary,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Bold);
            var lrt = (RectTransform)label.transform;
            StretchFull(lrt);

            refs.AccessibilityButton = btn;
            refs.AccessibilityButtonLabel = label;
        }

        private static TextMeshProUGUI CreateStatsText(RectTransform parent, string name, string text, float alignX, UIRefs refs)
        {
            var tmp = CreateText(parent, name, text,
                fontSize: 36, color: refs.Palette.textMuted,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Bold);
            var rt = (RectTransform)tmp.transform;

            // Anchor as a point along the bottom edge of the TopBar
            rt.anchorMin = new Vector2(alignX, 0f);
            rt.anchorMax = new Vector2(alignX, 0f);
            rt.pivot = new Vector2(alignX, 0f);
            rt.sizeDelta = new Vector2(360f, 50f);
            rt.anchoredPosition = new Vector2(
                alignX == 0f ? SideMargin : (alignX == 1f ? -SideMargin : 0f),
                30f);
            return tmp;
        }

        // ========================================================================
        // GRID AREA
        // ========================================================================

        private static void BuildGridArea(UIRefs refs)
        {
            const float verticalGap = 40f;

            // MiddleArea fills the gap between TopBar and BottomBar and reacts to
            // whatever aspect ratio the user's device (or Game view) actually is.
            var middle = new GameObject("MiddleArea", typeof(RectTransform));
            middle.transform.SetParent(refs.Screen, worldPositionStays: false);
            var middleRt = (RectTransform)middle.transform;
            middleRt.anchorMin = new Vector2(0f, 0f);
            middleRt.anchorMax = new Vector2(1f, 1f);
            middleRt.pivot = new Vector2(0.5f, 0.5f);
            middleRt.offsetMin = new Vector2(SideMargin, BottomBarHeight + verticalGap);
            middleRt.offsetMax = new Vector2(-SideMargin, -(TopBarHeight + verticalGap));

            // GridArea is always a square centered inside MiddleArea; AspectRatioFitter
            // keeps it from overflowing in either landscape or portrait viewports.
            var area = new GameObject("GridArea", typeof(RectTransform), typeof(AspectRatioFitter));
            area.transform.SetParent(middleRt, worldPositionStays: false);
            var rt = (RectTransform)area.transform;
            rt.anchorMin = new Vector2(0.5f, 0.5f);
            rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;

            var fitter = area.GetComponent<AspectRatioFitter>();
            fitter.aspectMode = AspectRatioFitter.AspectMode.FitInParent;
            fitter.aspectRatio = 1f;

            refs.GridArea = rt;

            // Column targets: top strip, offset right by the corner spacer
            var colGo = new GameObject("ColumnTargetsContainer", typeof(RectTransform), typeof(HorizontalLayoutGroup));
            colGo.transform.SetParent(rt, worldPositionStays: false);
            var colRt = (RectTransform)colGo.transform;
            colRt.anchorMin = new Vector2(0f, 1f);
            colRt.anchorMax = new Vector2(1f, 1f);
            colRt.pivot = new Vector2(0.5f, 1f);
            colRt.offsetMin = new Vector2(CornerSpacerSize, -TargetStripThickness);
            colRt.offsetMax = new Vector2(0f, 0f);

            var colHlg = colGo.GetComponent<HorizontalLayoutGroup>();
            colHlg.childControlWidth = true;
            colHlg.childControlHeight = true;
            colHlg.childForceExpandWidth = true;
            colHlg.childForceExpandHeight = true;
            colHlg.spacing = 8f;
            colHlg.padding = new RectOffset(0, 0, 0, 12);
            refs.ColumnTargetsContainer = colRt;
            refs.ColumnTargetsLayout = colHlg;

            // Row targets: left strip, offset down by the corner spacer
            var rowGo = new GameObject("RowTargetsContainer", typeof(RectTransform), typeof(VerticalLayoutGroup));
            rowGo.transform.SetParent(rt, worldPositionStays: false);
            var rowRt = (RectTransform)rowGo.transform;
            rowRt.anchorMin = new Vector2(0f, 0f);
            rowRt.anchorMax = new Vector2(0f, 1f);
            rowRt.pivot = new Vector2(0f, 0.5f);
            rowRt.offsetMin = new Vector2(0f, 0f);
            rowRt.offsetMax = new Vector2(TargetStripThickness, -CornerSpacerSize);

            var rowVlg = rowGo.GetComponent<VerticalLayoutGroup>();
            rowVlg.childControlWidth = true;
            rowVlg.childControlHeight = true;
            rowVlg.childForceExpandWidth = true;
            rowVlg.childForceExpandHeight = true;
            rowVlg.spacing = 8f;
            rowVlg.padding = new RectOffset(0, 12, 0, 0);
            refs.RowTargetsContainer = rowRt;
            refs.RowTargetsLayout = rowVlg;

            // Cells: fills the remaining square (bottom-right of the targets strips)
            var cellsGo = new GameObject("GridCellsContainer", typeof(RectTransform), typeof(GridLayoutGroup));
            cellsGo.transform.SetParent(rt, worldPositionStays: false);
            var cellsRt = (RectTransform)cellsGo.transform;
            cellsRt.anchorMin = new Vector2(0f, 0f);
            cellsRt.anchorMax = new Vector2(1f, 1f);
            cellsRt.pivot = new Vector2(0.5f, 0.5f);
            cellsRt.offsetMin = new Vector2(CornerSpacerSize, 0f);
            cellsRt.offsetMax = new Vector2(0f, -CornerSpacerSize);

            var grid = cellsGo.GetComponent<GridLayoutGroup>();
            grid.startCorner = GridLayoutGroup.Corner.UpperLeft;
            grid.startAxis = GridLayoutGroup.Axis.Horizontal;
            grid.childAlignment = TextAnchor.MiddleCenter;
            grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            grid.constraintCount = 3; // Phase 4 overrides based on puzzle size
            grid.spacing = new Vector2(8f, 8f);
            refs.GridCellsContainer = cellsRt;
            refs.GridCellsLayout = grid;
        }

        // ========================================================================
        // BOTTOM BAR
        // ========================================================================

        private static void BuildBottomBar(UIRefs refs)
        {
            var bar = new GameObject("BottomBar", typeof(RectTransform));
            bar.transform.SetParent(refs.Screen, worldPositionStays: false);

            var rt = (RectTransform)bar.transform;
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(1f, 0f);
            rt.pivot = new Vector2(0.5f, 0f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(0f, BottomBarHeight);
            refs.BottomBar = rt;

            // Horizontal layout: Reset | Hint | Confirm
            var hlg = bar.AddComponent<HorizontalLayoutGroup>();
            hlg.childControlWidth = true;
            hlg.childControlHeight = true;
            hlg.childForceExpandWidth = true;
            hlg.childForceExpandHeight = false;
            hlg.childAlignment = TextAnchor.MiddleCenter;
            hlg.spacing = BottomButtonSpacing;
            hlg.padding = new RectOffset((int)SideMargin, (int)SideMargin, 40, 40);

            refs.ResetButton = BuildActionButton(rt, "ResetButton", "Reset",
                bgColor: refs.Palette.buttonNeutral, textColor: refs.Palette.textPrimary, refs);

            refs.HintButton = BuildHintButton(rt, refs);

            refs.ConfirmButton = BuildActionButton(rt, "ConfirmButton", "Confirm",
                bgColor: refs.Palette.accent, textColor: refs.Palette.textOnAccent, refs);
        }

        private static Button BuildActionButton(
            RectTransform parent, string name, string label, Color bgColor, Color textColor, UIRefs refs)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, worldPositionStays: false);

            var le = go.AddComponent<LayoutElement>();
            le.minHeight = BottomButtonHeight;
            le.preferredHeight = BottomButtonHeight;

            var img = go.GetComponent<Image>();
            img.sprite = SpriteFactory.RoundedRect();
            img.type = Image.Type.Sliced;
            img.color = bgColor;

            var btn = go.GetComponent<Button>();
            var colors = btn.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 1f, 1f, 0.9f);
            colors.pressedColor = new Color(0.85f, 0.85f, 0.85f, 1f);
            colors.selectedColor = Color.white;
            colors.disabledColor = new Color(1f, 1f, 1f, 0.4f);
            btn.colors = colors;

            var tmp = CreateText((RectTransform)go.transform, "Label", label,
                fontSize: 44, color: textColor,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Bold);
            var textRt = (RectTransform)tmp.transform;
            StretchFull(textRt);
            textRt.offsetMin = new Vector2(16f, 12f);
            textRt.offsetMax = new Vector2(-16f, -12f);

            return btn;
        }

        private static Button BuildHintButton(RectTransform parent, UIRefs refs)
        {
            var btn = BuildActionButton(parent, "HintButton", "Hint",
                bgColor: refs.Palette.hintGlow, textColor: refs.Palette.textPrimary, refs);

            // Badge showing remaining hints (top-right corner)
            var badgeGo = new GameObject("HintBadge", typeof(RectTransform), typeof(Image));
            badgeGo.transform.SetParent(btn.transform, worldPositionStays: false);

            var badgeRt = (RectTransform)badgeGo.transform;
            badgeRt.anchorMin = new Vector2(1f, 1f);
            badgeRt.anchorMax = new Vector2(1f, 1f);
            badgeRt.pivot = new Vector2(1f, 1f);
            badgeRt.anchoredPosition = new Vector2(-8f, -8f);
            badgeRt.sizeDelta = new Vector2(56f, 56f);

            var badgeImg = badgeGo.GetComponent<Image>();
            badgeImg.sprite = SpriteFactory.Circle();
            badgeImg.color = refs.Palette.accent;
            badgeImg.raycastTarget = false;

            var badgeText = CreateText(badgeRt, "Count", "3",
                fontSize: 32, color: refs.Palette.textOnAccent,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Bold);
            var btRt = (RectTransform)badgeText.transform;
            StretchFull(btRt);
            refs.HintBadgeText = badgeText;

            return btn;
        }

        // ========================================================================
        // OVERLAYS
        // ========================================================================

        private static void BuildHintTooltip(UIRefs refs)
        {
            var go = new GameObject("HintTooltip", typeof(RectTransform), typeof(Image));
            go.transform.SetParent(refs.Screen, worldPositionStays: false);

            var rt = (RectTransform)go.transform;
            // Anchor to the TOP of the screen so the tooltip hugs the bottom of
            // the TopBar regardless of portrait/landscape aspect.
            rt.anchorMin = new Vector2(0.5f, 1f);
            rt.anchorMax = new Vector2(0.5f, 1f);
            rt.pivot = new Vector2(0.5f, 1f);
            rt.sizeDelta = new Vector2(880f, 150f);
            rt.anchoredPosition = new Vector2(0f, -(TopBarHeight + 20f));

            var img = go.GetComponent<Image>();
            img.sprite = SpriteFactory.RoundedRect();
            img.type = Image.Type.Sliced;
            img.color = new Color(0.98f, 0.96f, 0.88f, 0.97f);

            var body = CreateText(rt, "Body", "Tap Hint for a logical nudge.",
                fontSize: 32, color: refs.Palette.textPrimary,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Normal);
            var brt = (RectTransform)body.transform;
            StretchFull(brt);
            brt.offsetMin = new Vector2(40f, 40f);
            brt.offsetMax = new Vector2(-40f, -40f);

            refs.HintTooltip = rt;
            refs.HintTooltipText = body;
            go.SetActive(false);
        }

        private static void BuildLevelPickerOverlay(UIRefs refs)
        {
            var go = new GameObject("LevelPickerOverlay", typeof(RectTransform), typeof(Image));
            go.transform.SetParent(refs.Screen, worldPositionStays: false);

            var rt = (RectTransform)go.transform;
            StretchFull(rt);

            var scrim = go.GetComponent<Image>();
            scrim.color = new Color(0f, 0f, 0f, 0.55f);
            scrim.raycastTarget = true;

            var card = new GameObject("Card", typeof(RectTransform), typeof(Image));
            card.transform.SetParent(rt, worldPositionStays: false);
            var cardRt = (RectTransform)card.transform;
            cardRt.anchorMin = new Vector2(0.5f, 0.5f);
            cardRt.anchorMax = new Vector2(0.5f, 0.5f);
            cardRt.pivot = new Vector2(0.5f, 0.5f);
            cardRt.sizeDelta = new Vector2(880f, 1400f);
            cardRt.anchoredPosition = Vector2.zero;

            var cardImg = card.GetComponent<Image>();
            cardImg.sprite = SpriteFactory.RoundedRect();
            cardImg.type = Image.Type.Sliced;
            cardImg.color = Color.white;

            var title = CreateText(cardRt, "Title", "Levels",
                fontSize: 72, color: refs.Palette.textPrimary,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Bold);
            var trt = (RectTransform)title.transform;
            trt.anchorMin = new Vector2(0f, 1f);
            trt.anchorMax = new Vector2(1f, 1f);
            trt.pivot = new Vector2(0.5f, 1f);
            trt.anchoredPosition = new Vector2(0f, -32f);
            trt.sizeDelta = new Vector2(-80f, 120f);

            refs.LevelPickerCloseButton = BuildPickerCloseButton(cardRt, refs);

            var listGo = new GameObject("LevelList", typeof(RectTransform), typeof(VerticalLayoutGroup));
            listGo.transform.SetParent(cardRt, worldPositionStays: false);
            var listRt = (RectTransform)listGo.transform;
            listRt.anchorMin = new Vector2(0f, 0f);
            listRt.anchorMax = new Vector2(1f, 1f);
            listRt.pivot = new Vector2(0.5f, 0.5f);
            listRt.offsetMin = new Vector2(40f, 40f);
            listRt.offsetMax = new Vector2(-40f, -170f); // leave room for title

            var vlg = listGo.GetComponent<VerticalLayoutGroup>();
            vlg.childControlWidth = true;
            vlg.childControlHeight = false;
            vlg.childForceExpandWidth = true;
            vlg.childForceExpandHeight = false;
            vlg.spacing = 16f;
            vlg.padding = new RectOffset(0, 0, 0, 0);

            refs.LevelPickerOverlay = rt;
            refs.LevelPickerList = listRt;
            go.SetActive(false);
        }

        private static Button BuildPickerCloseButton(RectTransform cardRt, UIRefs refs)
        {
            var go = new GameObject("Close", typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(cardRt, worldPositionStays: false);

            var rt = (RectTransform)go.transform;
            rt.anchorMin = new Vector2(1f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(1f, 1f);
            rt.sizeDelta = new Vector2(72f, 72f);
            rt.anchoredPosition = new Vector2(-24f, -24f);

            var img = go.GetComponent<Image>();
            img.sprite = SpriteFactory.Circle();
            img.color = refs.Palette.buttonNeutral;

            var btn = go.GetComponent<Button>();
            var colors = btn.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 1f, 1f, 0.9f);
            colors.pressedColor = new Color(0.85f, 0.85f, 0.85f, 1f);
            btn.colors = colors;

            var label = CreateText(rt, "Label", "\u00D7", // multiplication sign as close glyph
                fontSize: 54, color: refs.Palette.textPrimary,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Bold);
            StretchFull((RectTransform)label.transform);
            return btn;
        }

        /// <summary>
        /// Construct a single level-picker row as a button with its display name,
        /// difficulty chip, and grid-size hint. Caller parents it under the picker list.
        /// </summary>
        public static Button BuildLevelPickerItem(RectTransform parent, ThemePalette palette,
            string displayName, string difficultyLabel, string sizeLabel, Color difficultyColor)
        {
            var go = new GameObject($"LevelItem_{displayName}",
                typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, worldPositionStays: false);

            var le = go.AddComponent<LayoutElement>();
            le.minHeight = 110f;
            le.preferredHeight = 110f;

            var img = go.GetComponent<Image>();
            img.sprite = SpriteFactory.RoundedRect();
            img.type = Image.Type.Sliced;
            img.color = palette.buttonNeutral;

            var btn = go.GetComponent<Button>();
            var colors = btn.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(1f, 1f, 1f, 0.9f);
            colors.pressedColor = new Color(0.85f, 0.85f, 0.85f, 1f);
            btn.colors = colors;

            var nameText = CreateText((RectTransform)go.transform, "Name", displayName,
                fontSize: 40, color: palette.textPrimary,
                alignment: TextAlignmentOptions.Left, style: FontStyles.Bold);
            var nrt = (RectTransform)nameText.transform;
            nrt.anchorMin = new Vector2(0f, 0f);
            nrt.anchorMax = new Vector2(0.55f, 1f);
            nrt.offsetMin = new Vector2(32f, 0f);
            nrt.offsetMax = new Vector2(0f, 0f);

            var sizeText = CreateText((RectTransform)go.transform, "Size", sizeLabel,
                fontSize: 28, color: palette.textMuted,
                alignment: TextAlignmentOptions.Left, style: FontStyles.Normal);
            var srt = (RectTransform)sizeText.transform;
            srt.anchorMin = new Vector2(0.55f, 0f);
            srt.anchorMax = new Vector2(0.80f, 1f);
            srt.offsetMin = Vector2.zero;
            srt.offsetMax = Vector2.zero;

            var chipGo = new GameObject("DifficultyChip", typeof(RectTransform), typeof(Image));
            chipGo.transform.SetParent((RectTransform)go.transform, worldPositionStays: false);
            var chipRt = (RectTransform)chipGo.transform;
            chipRt.anchorMin = new Vector2(1f, 0.5f);
            chipRt.anchorMax = new Vector2(1f, 0.5f);
            chipRt.pivot = new Vector2(1f, 0.5f);
            chipRt.sizeDelta = new Vector2(190f, 60f);
            chipRt.anchoredPosition = new Vector2(-24f, 0f);
            var chipImg = chipGo.GetComponent<Image>();
            chipImg.sprite = SpriteFactory.RoundedRect();
            chipImg.type = Image.Type.Sliced;
            chipImg.color = difficultyColor;

            var chipText = CreateText(chipRt, "Label", difficultyLabel,
                fontSize: 32, color: palette.textOnAccent,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Bold);
            StretchFull((RectTransform)chipText.transform);

            return btn;
        }

        private static void BuildWinOverlay(UIRefs refs)
        {
            var go = new GameObject("WinOverlay", typeof(RectTransform), typeof(Image));
            go.transform.SetParent(refs.Screen, worldPositionStays: false);

            var rt = (RectTransform)go.transform;
            StretchFull(rt);

            var scrim = go.GetComponent<Image>();
            scrim.color = new Color(0f, 0f, 0f, 0.5f);
            scrim.raycastTarget = true;

            // Card inside the scrim
            var card = new GameObject("Card", typeof(RectTransform), typeof(Image));
            card.transform.SetParent(rt, worldPositionStays: false);
            var cardRt = (RectTransform)card.transform;
            cardRt.anchorMin = new Vector2(0.5f, 0.5f);
            cardRt.anchorMax = new Vector2(0.5f, 0.5f);
            cardRt.pivot = new Vector2(0.5f, 0.5f);
            cardRt.sizeDelta = new Vector2(760f, 520f);
            cardRt.anchoredPosition = Vector2.zero;

            var cardImg = card.GetComponent<Image>();
            cardImg.sprite = SpriteFactory.RoundedRect();
            cardImg.type = Image.Type.Sliced;
            cardImg.color = Color.white;

            refs.WinCard = cardRt;

            var title = CreateText(cardRt, "Title", "Solved!",
                fontSize: 96, color: refs.Palette.textPrimary,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Bold);
            var trt = (RectTransform)title.transform;
            trt.anchorMin = new Vector2(0f, 1f);
            trt.anchorMax = new Vector2(1f, 1f);
            trt.pivot = new Vector2(0.5f, 1f);
            trt.anchoredPosition = new Vector2(0f, -40f);
            trt.sizeDelta = new Vector2(-40f, 160f);

            var stats = CreateText(cardRt, "Stats", "Level 1 - 0 moves",
                fontSize: 40, color: refs.Palette.textMuted,
                alignment: TextAlignmentOptions.Center, style: FontStyles.Normal);
            var srt = (RectTransform)stats.transform;
            srt.anchorMin = new Vector2(0f, 0.5f);
            srt.anchorMax = new Vector2(1f, 0.5f);
            srt.pivot = new Vector2(0.5f, 0.5f);
            srt.anchoredPosition = new Vector2(0f, 0f);
            srt.sizeDelta = new Vector2(-40f, 80f);
            refs.WinStatsText = stats;

            var next = BuildActionButton(cardRt, "NextButton", "Next Level",
                bgColor: refs.Palette.accent, textColor: refs.Palette.textOnAccent, refs);
            var nrt = (RectTransform)next.transform;
            nrt.anchorMin = new Vector2(0.5f, 0f);
            nrt.anchorMax = new Vector2(0.5f, 0f);
            nrt.pivot = new Vector2(0.5f, 0f);
            nrt.sizeDelta = new Vector2(500f, BottomButtonHeight);
            nrt.anchoredPosition = new Vector2(0f, 60f);
            refs.WinNextButton = next;

            refs.WinOverlay = rt;
            go.SetActive(false);
        }

        // ========================================================================
        // HELPERS
        // ========================================================================

        private static TextMeshProUGUI CreateText(
            RectTransform parent, string name, string text,
            float fontSize, Color color, TextAlignmentOptions alignment, FontStyles style = FontStyles.Normal)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, worldPositionStays: false);
            StretchFull((RectTransform)go.transform);

            var tmp = go.AddComponent<TextMeshProUGUI>();
            tmp.text = text;
            tmp.fontSize = fontSize;
            tmp.color = color;
            tmp.alignment = alignment;
            tmp.fontStyle = style;
            tmp.enableWordWrapping = true;
            tmp.raycastTarget = false;
            tmp.richText = true;
            return tmp;
        }

        private static void StretchFull(RectTransform rt)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
        }

        private static void EnsureEventSystem()
        {
            if (Object.FindObjectOfType<EventSystem>() != null) return;

            var go = new GameObject("[EventSystem]", typeof(EventSystem), typeof(StandaloneInputModule));
            Object.DontDestroyOnLoad(go);
        }
    }
}
